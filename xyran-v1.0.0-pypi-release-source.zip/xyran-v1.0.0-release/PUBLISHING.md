# Publishing Xyran V1 to PyPI

The release source ZIP intentionally does **not** contain a fake/placeholder
ONNX model. `BUILD_RELEASE.bat` downloads the exact pinned model, verifies its
SHA256, copies it into the Python package, then builds the wheel and sdist.

The resulting artifacts **do contain the model**, so end users only need:

```bash
pip install xyran
```

## 1. Build the release on Windows

From the extracted project directory:

```bat
BUILD_RELEASE.bat
```

It will:

1. create an isolated `.release-venv`;
2. download the exact pinned Owen-S ONNX model (HF, then hf-mirror fallback);
3. verify file size and SHA256;
4. run unit/regression tests;
5. build wheel + sdist;
6. run `twine check`;
7. inspect both archives and verify the model is actually bundled.

Expected files:

```text
dist\xyran-1.0.0-py3-none-any.whl
dist\xyran-1.0.0.tar.gz
```

## 2. End-user install rehearsal

Before publishing:

```bat
TEST_LOCAL_INSTALL.bat
```

This creates a clean install environment, installs the built wheel with all
runtime dependencies, then runs:

```text
xyran doctor
```

On Windows x64 this intentionally downloads the ONNX Runtime GPU package plus
pip-managed CUDA/cuDNN runtime dependencies. This can be a large download.

## 3. PyPI account/token

Create a PyPI API token for the project/account. With Twine you can either enter
credentials interactively or use environment variables:

```bat
set TWINE_USERNAME=__token__
set TWINE_PASSWORD=pypi-xxxxxxxxxxxxxxxx
```

Do not commit the token.

## 4. Optional TestPyPI upload

```bat
.release-venv\Scripts\python -m twine upload --repository testpypi dist\*
```

Because runtime dependencies live on normal PyPI, installation from TestPyPI
usually needs normal PyPI as an extra index.

## 5. Production upload

```bat
.release-venv\Scripts\python -m twine upload dist\*
```

Then verify from a new environment:

```bat
python -m venv verify-pypi
verify-pypi\Scripts\activate
python -m pip install --upgrade pip
pip install xyran==1.0.0
xyran doctor
```

## Important dependency note

ONNX Runtime publishes separate CPU and GPU distributions which share the same
Python import namespace. Xyran's environment markers install exactly
one runtime on a clean environment. If a user already has the opposite ORT
package installed, `xyran doctor` detects the conflict and explains
how to clean it.
