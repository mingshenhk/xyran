@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"

if not exist "dist\xyran-1.0.0-py3-none-any.whl" (
  echo ERROR: built wheel not found. Run BUILD_RELEASE.bat first.
  exit /b 1
)

if exist .install-test rmdir /s /q .install-test
python -m venv .install-test || exit /b 1
call .install-test\Scripts\activate.bat || exit /b 1
python -m pip install --upgrade pip || exit /b 1
python -m pip install dist\xyran-1.0.0-py3-none-any.whl || exit /b 1

echo.
echo ============================================================
echo Running end-user doctor test...
echo ============================================================
xyran doctor || exit /b 1

echo.
echo Creating a local end-to-end smoke image...
python -c "from PIL import Image; Image.new('RGB',(739,1000),(40,80,120)).save('_xyran_smoke.png')" || exit /b 1
xyran scan _xyran_smoke.png --json || exit /b 1
del /q _xyran_smoke.png >nul 2>nul

echo.
echo [SUCCESS] Clean end-user installation + real inference smoke test passed.
exit /b 0
