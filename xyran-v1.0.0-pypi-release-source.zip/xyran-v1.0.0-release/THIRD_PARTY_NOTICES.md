# Third-Party Notices

## OwenElliott/image-safety-classifier-s

Xyran V1 redistributes the pinned ONNX model file from:

- Repository: `OwenElliott/image-safety-classifier-s`
- Source: Hugging Face
- Source commit: `eb8b0b203952b70db191e990217174af4af39767`
- File: `onnx/image-safety-classifier-s.onnx`
- SHA256: `fef443ed68ae25ed693b6fef9e456071692ed3963cff4168acb39c3de6f017e7`
- Size: `23,701,765` bytes
- Repository license metadata: MIT

The model is not authored by the Xyran project. The model author's
model card states that the classifier predicts NSFW, NSFL, and SFW and that
mistakes are possible.

The MIT license text used for redistribution is included at:

`src/xyran/third_party/OWEN_MODEL_MIT_LICENSE.txt`

## pyvips / libvips

Xyran depends on `pyvips[binary]` for the default high-speed image
preprocessing path. pyvips/libvips retain their respective upstream licenses.

## ONNX Runtime

Xyran depends on Microsoft ONNX Runtime. Windows/Linux x64 installs
use the CUDA-capable Python distribution; other supported targets use the CPU
Python distribution. ONNX Runtime retains its upstream license.
