from __future__ import annotations

import argparse
import json
import platform
import sys

from . import __version__
from .exceptions import XyranError
from .model_info import resolve_model_path, verify_bundled_model
from .moderator import Moderator
from .preprocess import pyvips_diagnostics
from .runtime import runtime_diagnostics


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="xyran")
    p.add_argument("--version", action="version", version=__version__)
    sub = p.add_subparsers(dest="command", required=True)

    scan = sub.add_parser("scan", help="Moderate one local image")
    scan.add_argument("image")
    scan.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto")
    scan.add_argument("--preprocess", choices=["blurpad", "warp"], default="blurpad")
    scan.add_argument(
        "--resident",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    scan.add_argument("--json", action="store_true")

    doctor = sub.add_parser("doctor", help="Inspect local model/runtime readiness")
    doctor.add_argument("--json", action="store_true")
    return p


def doctor(as_json: bool) -> int:
    try:
        model_path, bundled = resolve_model_path(None)
        model = verify_bundled_model(str(model_path))
        model_status = "OK"
        model_error = None
    except Exception as exc:
        model_path = None
        bundled = True
        model = None
        model_status = "ERROR"
        model_error = f"{type(exc).__name__}: {exc}"

    runtime = runtime_diagnostics(model_path) if model_path else {
        "status": "NOT_TESTED",
        "error": "Model unavailable",
    }
    vips = pyvips_diagnostics()

    ready = (
        model_status == "OK"
        and runtime.get("status") == "READY"
        and vips.get("available") is True
    )

    payload = {
        "sdk_version": __version__,
        "python_version": platform.python_version(),
        "model_status": model_status,
        "model": model,
        "model_error": model_error,
        "runtime": runtime,
        "image_backend": vips,
        "defaults": {
            "preprocess": "blurpad_lanczos3",
            "tiling": False,
            "resident": True,
            "device": "auto",
        },
        "privacy": {
            "telemetry": False,
            "cloud_api": False,
            "network_required_for_inference": False,
        },
        "overall": "READY" if ready else "NOT_READY",
    }

    if as_json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0 if ready else 1

    print(f"Xyran V1    {__version__}")
    print(f"Python                {payload['python_version']}")
    print("")
    print(f"Model                 {'BUNDLED / VERIFIED' if model_status == 'OK' else 'ERROR'}")
    if model:
        print(f"Model bytes           {model['size_bytes']}")
        print(f"Model SHA256          {model['sha256'][:16]}...")
    if model_error:
        print(f"Model error           {model_error}")
    print("")
    print(f"pyvips                {vips.get('version') if vips.get('available') else 'UNAVAILABLE'}")
    print("Default preprocess    BlurPad + Lanczos3")
    print("Optional preprocess   Warp + Linear")
    print("Tiling                OFF")
    print("Model resident        YES")
    print("")
    print(f"Runtime status        {runtime.get('status')}")
    if runtime.get("version"):
        print(f"ONNX Runtime          {runtime['version']}")
    if runtime.get("available_providers"):
        print("Providers             " + ", ".join(runtime["available_providers"]))
    if runtime.get("cuda_preload"):
        print(f"CUDA DLL preload      {runtime['cuda_preload']}")
    if runtime.get("active_provider"):
        print(f"Active provider       {runtime['active_provider']}")
    if runtime.get("smoke_test"):
        print(f"Runtime smoke test    {runtime['smoke_test']}")
    if runtime.get("error"):
        print(f"Runtime error         {runtime['error']}")
    print("")
    print("Telemetry             DISABLED")
    print("Cloud API             NONE")
    print("Inference             LOCAL")
    print("Network for inference NO")
    print(f"Overall               {'READY' if ready else 'NOT READY'}")
    return 0 if ready else 1


def main() -> int:
    args = parser().parse_args()
    try:
        if args.command == "doctor":
            return doctor(args.json)

        mod = Moderator(
            device=args.device,
            preprocess=args.preprocess,
            resident=args.resident,
        )
        try:
            result = mod.scan(args.image)
        finally:
            mod.close()

        if args.json:
            print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
        else:
            p = result.processing
            print(result.decision)
            print(f"sexual   {result.scores.sexual:.4f}")
            print(f"graphic  {result.scores.graphic:.4f}")
            print(f"safe     {result.scores.safe:.4f}")
            print(f"provider {result.provider}")
            print(f"fallback {result.runtime_fallback}")
            print(f"image    {p.original_width}x{p.original_height}")
            print(f"prep     {p.preprocess}")
            print(f"resident {p.model_resident}")
            print(f"prep_ms  {p.preprocess_ms:.3f}")
            print(f"infer_ms {p.inference_ms:.3f}")
            print(f"total_ms {p.total_ms:.3f}")
            for warning in result.warnings:
                print(f"warning  {warning}")
        return 0
    except (XyranError, RuntimeError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
