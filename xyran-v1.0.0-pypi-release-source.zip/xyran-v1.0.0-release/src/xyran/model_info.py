from __future__ import annotations

from functools import lru_cache
from importlib import resources
from pathlib import Path
import hashlib
import json

from .exceptions import ModelIntegrityError, ModelNotFoundError

MODEL_FILENAME = "image-safety-classifier-s.onnx"
EXPECTED_MODEL_SIZE = 23_701_765
EXPECTED_MODEL_SHA256 = (
    "fef443ed68ae25ed693b6fef9e456071"
    "692ed3963cff4168acb39c3de6f017e7"
)
MODEL_SOURCE_COMMIT = "eb8b0b203952b70db191e990217174af4af39767"
MODEL_REPOSITORY = "OwenElliott/image-safety-classifier-s"


def bundled_model_path() -> Path:
    traversable = resources.files("xyran.models").joinpath(MODEL_FILENAME)
    path = Path(str(traversable))
    if not path.is_file():
        raise ModelNotFoundError(
            "Bundled Owen-S model is missing from this installation. "
            "Reinstall Xyran from the official wheel."
        )
    return path


def resolve_model_path(explicit: str | Path | None = None) -> tuple[Path, bool]:
    if explicit is not None:
        path = Path(explicit).expanduser().resolve()
        if not path.is_file():
            raise ModelNotFoundError(f"Model not found: {path}")
        return path, False
    return bundled_model_path(), True


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


@lru_cache(maxsize=4)
def verify_bundled_model(path_text: str | None = None) -> dict:
    path = Path(path_text) if path_text else bundled_model_path()
    size = path.stat().st_size
    if size != EXPECTED_MODEL_SIZE:
        raise ModelIntegrityError(
            f"Bundled model size mismatch: got {size}, expected {EXPECTED_MODEL_SIZE}."
        )
    digest = sha256_file(path)
    if digest != EXPECTED_MODEL_SHA256:
        raise ModelIntegrityError(
            "Bundled model SHA256 mismatch. Reinstall Xyran from a trusted source."
        )
    return {
        "path": str(path),
        "size_bytes": size,
        "sha256": digest,
        "repository": MODEL_REPOSITORY,
        "source_commit": MODEL_SOURCE_COMMIT,
    }
