The release source archive intentionally omits the 23.7 MB ONNX binary.
Run BUILD_RELEASE.bat; it downloads the exact pinned model, verifies SHA256,
and then builds wheel/sdist with the model physically bundled.
