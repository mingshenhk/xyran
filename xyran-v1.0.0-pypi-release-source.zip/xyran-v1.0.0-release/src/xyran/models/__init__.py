"""Bundled Xyran model resources."""
