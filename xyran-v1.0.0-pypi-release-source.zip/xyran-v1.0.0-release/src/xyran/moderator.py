from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
from threading import RLock
from time import perf_counter
from typing import Iterable
import gc

import numpy as np

from .model_info import resolve_model_path, verify_bundled_model
from .policy import ModerationPolicy
from .preprocess import DEFAULT_MAX_PIXELS, ImageInput, preprocess_image
from .result import ModerationResult, ModerationScores, ProcessingInfo
from .runtime import create_cpu_session, create_session


class Moderator:
    """Xyran V1 local image moderation API."""

    def __init__(
        self,
        *,
        model_path: str | Path | None = None,
        device: str = "auto",
        policy: ModerationPolicy | None = None,
        preprocess: str = "blurpad",
        resident: bool = True,
        max_pixels: int = DEFAULT_MAX_PIXELS,
        verify_model: bool = True,
    ) -> None:
        self.model_path, self._bundled_model = resolve_model_path(model_path)
        if self._bundled_model and verify_model:
            verify_bundled_model(str(self.model_path))

        self.requested_device = device.lower()
        self.policy = policy or ModerationPolicy()
        self.preprocess = preprocess.lower()
        if self.preprocess not in {"blurpad", "warp"}:
            raise ValueError("preprocess must be one of: blurpad, warp")
        self.resident = bool(resident)
        self.max_pixels = max_pixels

        self._session = None
        self._input_name = None
        self._provider = None
        self._runtime_fallback = False
        self._warnings: list[str] = []
        self._lock = RLock()

        if self.resident:
            self.load()

    @property
    def is_loaded(self) -> bool:
        return self._session is not None

    @property
    def provider(self) -> str | None:
        return self._provider

    def _refresh_metadata(self) -> None:
        inputs = self._session.get_inputs()
        if len(inputs) != 1:
            raise RuntimeError(f"Expected one ONNX input, found {len(inputs)}")
        shape = inputs[0].shape
        if len(shape) != 4 or shape[2] != 224 or shape[3] != 224:
            raise RuntimeError(
                f"Expected an Owen-S-compatible [batch,3,224,224] input, got {shape}"
            )
        self._input_name = inputs[0].name
        providers = self._session.get_providers()
        self._provider = providers[0] if providers else "unknown"

    def load(self) -> "Moderator":
        with self._lock:
            if self._session is not None:
                return self
            # A new session starts a new runtime lifecycle. Do not leak a prior
            # non-resident fallback flag/warning into this operation.
            self._runtime_fallback = False
            self._warnings = []
            session, fallback, warnings = create_session(
                self.model_path, self.requested_device
            )
            self._session = session
            self._runtime_fallback = self._runtime_fallback or fallback
            for warning in warnings:
                if warning not in self._warnings:
                    self._warnings.append(warning)
            self._refresh_metadata()
            return self

    def unload(self) -> None:
        with self._lock:
            self._session = None
            self._input_name = None
            self._provider = None
            gc.collect()

    close = unload

    def __enter__(self) -> "Moderator":
        self.load()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    @contextmanager
    def _operation_session(self):
        self.load()
        try:
            yield
        finally:
            if not self.resident:
                self.unload()

    def _fallback_to_cpu(self, reason: Exception) -> None:
        if self.requested_device != "auto" or self._provider != "CUDAExecutionProvider":
            raise reason
        warning = (
            "CUDA inference failed; CPU fallback was used. "
            f"{type(reason).__name__}: {reason}"
        )
        if warning not in self._warnings:
            self._warnings.append(warning)
        self._session = create_cpu_session(self.model_path)
        self._runtime_fallback = True
        self._refresh_metadata()

    def _infer(self, tensor: np.ndarray) -> np.ndarray:
        try:
            raw = self._session.run(None, {self._input_name: tensor})[0]
        except Exception as exc:
            self._fallback_to_cpu(exc)
            raw = self._session.run(None, {self._input_name: tensor})[0]

        probs = np.asarray(raw, dtype=np.float32).reshape(-1)
        if probs.size != 3:
            raise RuntimeError(
                f"Expected 3 model probabilities [NSFL,NSFW,SFW], got {np.asarray(raw).shape}"
            )
        return probs

    def _scan_loaded(self, image: ImageInput) -> ModerationResult:
        total_start = perf_counter()
        prep_start = perf_counter()
        prepared = preprocess_image(
            image,
            preprocess=self.preprocess,
            max_pixels=self.max_pixels,
        )
        preprocess_ms = (perf_counter() - prep_start) * 1000.0

        infer_start = perf_counter()
        probs = self._infer(prepared.tensor)
        inference_ms = (perf_counter() - infer_start) * 1000.0

        # Owen-S class order: [NSFL, NSFW, SFW].
        scores = ModerationScores(
            graphic=float(probs[0]),
            sexual=float(probs[1]),
            safe=float(probs[2]),
        )
        decision, category, score, threshold = self.policy.decide(scores)
        total_ms = (perf_counter() - total_start) * 1000.0

        return ModerationResult(
            schema_version="1.0",
            scores=scores,
            decision=decision,
            trigger_category=category,
            trigger_score=score,
            threshold=threshold,
            provider=self._provider or "unknown",
            runtime_fallback=self._runtime_fallback,
            warnings=tuple([*prepared.warnings, *self._warnings]),
            processing=ProcessingInfo(
                original_width=prepared.width,
                original_height=prepared.height,
                preprocess=prepared.preprocess,
                image_backend=prepared.backend,
                model_resident=self.resident,
                preprocess_ms=round(preprocess_ms, 4),
                inference_ms=round(inference_ms, 4),
                total_ms=round(total_ms, 4),
            ),
        )

    def scan(self, image: ImageInput) -> ModerationResult:
        with self._operation_session():
            return self._scan_loaded(image)

    def scan_batch(self, images: Iterable[ImageInput]) -> list[ModerationResult]:
        """Reuse one ONNX session across a sequence of images."""
        items = list(images)
        if not items:
            return []

        with self._operation_session():
            return [self._scan_loaded(image) for image in items]
