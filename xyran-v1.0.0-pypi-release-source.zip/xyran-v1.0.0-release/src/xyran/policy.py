from __future__ import annotations

from dataclasses import dataclass

from .result import ModerationScores


@dataclass(frozen=True)
class ModerationPolicy:
    """Application policy thresholds; calibrate these on your own dataset."""

    sexual_review: float = 0.35
    sexual_block: float = 0.85
    graphic_review: float = 0.35
    graphic_block: float = 0.85

    def __post_init__(self) -> None:
        for name, value in vars(self).items():
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must be between 0 and 1")
        if self.sexual_review > self.sexual_block:
            raise ValueError("sexual_review must be <= sexual_block")
        if self.graphic_review > self.graphic_block:
            raise ValueError("graphic_review must be <= graphic_block")

    def decide(self, scores: ModerationScores):
        block = []
        if scores.sexual >= self.sexual_block:
            block.append(("sexual", scores.sexual, self.sexual_block))
        if scores.graphic >= self.graphic_block:
            block.append(("graphic", scores.graphic, self.graphic_block))
        if block:
            category, score, threshold = max(block, key=lambda x: x[1])
            return "BLOCK", category, score, threshold

        review = []
        if scores.sexual >= self.sexual_review:
            review.append(("sexual", scores.sexual, self.sexual_review))
        if scores.graphic >= self.graphic_review:
            review.append(("graphic", scores.graphic, self.graphic_review))
        if review:
            category, score, threshold = max(review, key=lambda x: x[1])
            return "REVIEW", category, score, threshold

        return "ALLOW", None, None, None
