from __future__ import annotations

from dataclasses import dataclass
from importlib import import_module
from io import BytesIO
from pathlib import Path
from typing import Union

import numpy as np
from PIL import Image, ImageOps, UnidentifiedImageError

from .exceptions import ImageBackendError, InvalidImageError

ImageInput = Union[str, Path, bytes, bytearray, Image.Image]
TARGET = 224
DEFAULT_MAX_PIXELS = 80_000_000
Image.MAX_IMAGE_PIXELS = DEFAULT_MAX_PIXELS


@dataclass(frozen=True)
class PreparedImage:
    tensor: np.ndarray
    width: int
    height: int
    preprocess: str
    backend: str
    warnings: tuple[str, ...] = ()


def fit_dimensions(width: int, height: int, target: int = TARGET) -> tuple[int, int]:
    if width <= 0 or height <= 0:
        raise InvalidImageError("Image dimensions must be positive")
    scale = min(target / width, target / height)
    out_w = max(1, min(target, round(width * scale)))
    out_h = max(1, min(target, round(height * scale)))
    return out_w, out_h


def _pyvips():
    try:
        return import_module("pyvips")
    except Exception as exc:
        raise ImageBackendError(
            "pyvips/libvips is unavailable. Reinstall Xyran so the "
            "`pyvips[binary]` dependency is present."
        ) from exc


def pyvips_diagnostics() -> dict:
    try:
        vips = import_module("pyvips")
        return {
            "available": True,
            "version": getattr(vips, "__version__", "unknown"),
            "api_mode": getattr(vips, "API_mode", None),
            "error": None,
        }
    except Exception as exc:
        return {
            "available": False,
            "version": None,
            "api_mode": None,
            "error": f"{type(exc).__name__}: {exc}",
        }


def _pil_to_vips(image: Image.Image):
    vips = _pyvips()
    image = ImageOps.exif_transpose(image).convert("RGB")
    arr = np.ascontiguousarray(np.asarray(image, dtype=np.uint8))
    return vips.Image.new_from_memory(
        arr.tobytes(), image.width, image.height, 3, "uchar"
    )


def _load_vips(source: ImageInput):
    vips = _pyvips()

    try:
        if isinstance(source, Image.Image):
            return _pil_to_vips(source)

        if isinstance(source, (bytes, bytearray)):
            image = vips.Image.new_from_buffer(
                bytes(source), "", access="random", fail_on="error"
            )
        else:
            image = vips.Image.new_from_file(
                str(Path(source)), access="random", fail_on="error"
            )

        image = image.autorot()

        try:
            if image.hasalpha():
                image = image.flatten(background=[255, 255, 255])
        except Exception:
            pass

        try:
            image = image.colourspace("srgb")
        except Exception:
            pass

        if image.bands == 1:
            band = image.extract_band(0)
            image = band.bandjoin([band, band])
        elif image.bands == 2:
            band = image.extract_band(0)
            image = band.bandjoin([band, band])
        elif image.bands >= 3:
            image = image.extract_band(0, n=3)

        if image.format != "uchar":
            image = image.cast("uchar")

        return image

    except Exception as vips_exc:
        # Compatibility fallback: decode with Pillow, then return to the same
        # libvips preprocessing pipeline. This preserves BlurPad/Warp semantics.
        try:
            if isinstance(source, Image.Image):
                return _pil_to_vips(source)
            if isinstance(source, (bytes, bytearray)):
                pil = Image.open(BytesIO(source))
            else:
                pil = Image.open(Path(source))
            pil.load()
            return _pil_to_vips(pil)
        except (OSError, ValueError, UnidentifiedImageError) as pil_exc:
            raise InvalidImageError(
                f"Unable to decode image. libvips: {vips_exc}; Pillow: {pil_exc}"
            ) from pil_exc


def _validate_size(width: int, height: int, max_pixels: int) -> None:
    pixels = width * height
    if pixels > max_pixels:
        raise InvalidImageError(
            f"Image too large: {width}x{height} = {pixels:,} pixels; "
            f"limit is {max_pixels:,}."
        )


def _resize_exact(image, width: int, height: int, kernel: str):
    out = image.resize(
        width / image.width,
        vscale=height / image.height,
        kernel=kernel,
    )
    if out.width != width or out.height != height:
        out = image.thumbnail_image(
            width, height=height, size="force", no_rotate=True
        )
    return out


def _blurpad_lanczos3(image):
    width, height = int(image.width), int(image.height)

    # Full-canvas blurred context background.
    background = _resize_exact(image, TARGET, TARGET, "lanczos3")
    background = background.gaussblur(10.0)

    # Sharp foreground preserves source geometry and every source edge.
    fit_w, fit_h = fit_dimensions(width, height, TARGET)
    foreground = _resize_exact(image, fit_w, fit_h, "lanczos3")

    x = (TARGET - fit_w) // 2
    y = (TARGET - fit_h) // 2
    return background.insert(foreground, x, y)


def _warp_linear(image):
    return _resize_exact(image, TARGET, TARGET, "linear")


def _to_tensor(image) -> np.ndarray:
    if image.bands != 3:
        if image.bands > 3:
            image = image.extract_band(0, n=3)
        else:
            raise InvalidImageError(
                f"Expected 3 color bands after preprocessing, got {image.bands}."
            )
    if image.format != "uchar":
        image = image.cast("uchar")
    if image.width != TARGET or image.height != TARGET:
        raise RuntimeError(
            f"Internal preprocessing error: got {image.width}x{image.height}, "
            f"expected {TARGET}x{TARGET}."
        )

    memory = image.write_to_memory()
    pixels = np.frombuffer(
        memory,
        dtype=np.uint8,
        count=TARGET * TARGET * 3,
    ).reshape((TARGET, TARGET, 3))

    tensor = pixels.astype(np.float32).transpose(2, 0, 1)[None, ...]
    return np.ascontiguousarray(tensor)


def preprocess_image(
    source: ImageInput,
    *,
    preprocess: str = "blurpad",
    max_pixels: int = DEFAULT_MAX_PIXELS,
) -> PreparedImage:
    mode = preprocess.lower().strip()
    if mode not in {"blurpad", "warp"}:
        raise ValueError("preprocess must be one of: blurpad, warp")
    if max_pixels <= 0:
        raise ValueError("max_pixels must be > 0")

    image = _load_vips(source)
    width, height = int(image.width), int(image.height)
    _validate_size(width, height, max_pixels)

    if mode == "blurpad":
        output = _blurpad_lanczos3(image)
        label = "blurpad_lanczos3"
    else:
        output = _warp_linear(image)
        label = "warp_linear"

    return PreparedImage(
        tensor=_to_tensor(output),
        width=width,
        height=height,
        preprocess=label,
        backend="pyvips",
    )
