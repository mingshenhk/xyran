from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Literal

Decision = Literal["ALLOW", "REVIEW", "BLOCK"]


@dataclass(frozen=True)
class ModerationScores:
    sexual: float
    graphic: float
    safe: float

    @property
    def primary_class(self) -> str:
        values = {
            "sexual": self.sexual,
            "graphic": self.graphic,
            "safe": self.safe,
        }
        return max(values, key=values.get)

    @property
    def confidence(self) -> float:
        return max(self.sexual, self.graphic, self.safe)


@dataclass(frozen=True)
class ProcessingInfo:
    original_width: int
    original_height: int
    preprocess: str
    image_backend: str
    model_resident: bool
    preprocess_ms: float
    inference_ms: float
    total_ms: float


@dataclass(frozen=True)
class ModerationResult:
    schema_version: str
    scores: ModerationScores
    decision: Decision
    trigger_category: str | None
    trigger_score: float | None
    threshold: float | None
    provider: str
    runtime_fallback: bool
    warnings: tuple[str, ...]
    processing: ProcessingInfo
    model: str = "OwenElliott/image-safety-classifier-s"

    def to_dict(self) -> dict:
        return asdict(self)
