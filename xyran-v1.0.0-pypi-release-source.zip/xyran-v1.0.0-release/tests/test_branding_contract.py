from pathlib import Path
import tomllib

ROOT = Path(__file__).resolve().parents[1]
OLD = "local" + "moderation"


def test_distribution_name_is_xyran():
    data = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    assert data["project"]["name"] == "xyran"


def test_cli_name_is_xyran():
    data = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    assert data["project"]["scripts"]["xyran"] == "xyran.cli:main"


def test_package_directory_is_xyran_only():
    assert (ROOT / "src" / "xyran").is_dir()
    assert not (ROOT / "src" / OLD).exists()


def test_no_old_brand_in_release_text():
    excluded = {".release-venv", ".local-install-test", "dist", "build", ".wheel-check"}
    offenders = []

    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        if any(part in excluded for part in path.parts):
            continue
        if path.suffix.lower() not in {".py", ".toml", ".md", ".txt", ".in", ".bat"} and path.name != "LICENSE":
            continue
        if OLD in path.read_text(encoding="utf-8", errors="ignore").lower():
            offenders.append(str(path.relative_to(ROOT)))

    assert offenders == []


def test_readme_install_and_import():
    text = (ROOT / "README.md").read_text(encoding="utf-8")
    assert "pip install xyran" in text
    assert "from xyran import Moderator" in text
    assert "xyran doctor" in text
