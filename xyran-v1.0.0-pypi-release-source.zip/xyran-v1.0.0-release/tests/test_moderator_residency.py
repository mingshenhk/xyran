from pathlib import Path
import numpy as np

import xyran.moderator as mm
from xyran.preprocess import PreparedImage


class Input:
    name = "image"
    shape = ["batch_size", 3, 224, 224]


class FakeSession:
    def get_inputs(self):
        return [Input()]

    def get_providers(self):
        return ["CPUExecutionProvider"]

    def run(self, outputs, feed):
        return [np.array([[0.02, 0.10, 0.88]], dtype=np.float32)]


def fake_preprocess(*args, **kwargs):
    return PreparedImage(
        tensor=np.zeros((1, 3, 224, 224), dtype=np.float32),
        width=739,
        height=1000,
        preprocess="blurpad_lanczos3",
        backend="pyvips",
    )


def test_resident_loads_once(monkeypatch, tmp_path):
    model = tmp_path / "m.onnx"
    model.write_bytes(b"x")
    calls = []

    def fake_create(path, device):
        calls.append((path, device))
        return FakeSession(), False, []

    monkeypatch.setattr(mm, "create_session", fake_create)
    monkeypatch.setattr(mm, "preprocess_image", fake_preprocess)

    mod = mm.Moderator(model_path=model, resident=True, verify_model=False)
    mod.scan("a.jpg")
    mod.scan("b.jpg")
    assert len(calls) == 1
    assert mod.is_loaded
    mod.close()
    assert not mod.is_loaded


def test_nonresident_reloads(monkeypatch, tmp_path):
    model = tmp_path / "m.onnx"
    model.write_bytes(b"x")
    calls = []

    def fake_create(path, device):
        calls.append((path, device))
        return FakeSession(), False, []

    monkeypatch.setattr(mm, "create_session", fake_create)
    monkeypatch.setattr(mm, "preprocess_image", fake_preprocess)

    mod = mm.Moderator(model_path=model, resident=False, verify_model=False)
    mod.scan("a.jpg")
    mod.scan("b.jpg")
    assert len(calls) == 2
    assert not mod.is_loaded
