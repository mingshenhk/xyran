from xyran import ModerationPolicy
from xyran.result import ModerationScores


def test_policy_allow_review_block():
    p = ModerationPolicy()
    assert p.decide(ModerationScores(0.1, 0.1, 0.8))[0] == "ALLOW"
    assert p.decide(ModerationScores(0.5, 0.1, 0.4))[0] == "REVIEW"
    assert p.decide(ModerationScores(0.9, 0.02, 0.08))[0] == "BLOCK"


def test_policy_rejects_bad_ranges():
    try:
        ModerationPolicy(sexual_review=0.9, sexual_block=0.8)
    except ValueError:
        pass
    else:
        raise AssertionError("Expected ValueError")
