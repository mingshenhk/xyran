from xyran.preprocess import fit_dimensions


def test_portrait_fit():
    assert fit_dimensions(739, 1000) == (166, 224)


def test_landscape_fit():
    assert fit_dimensions(1000, 739) == (224, 166)


def test_square_fit():
    assert fit_dimensions(500, 500) == (224, 224)
