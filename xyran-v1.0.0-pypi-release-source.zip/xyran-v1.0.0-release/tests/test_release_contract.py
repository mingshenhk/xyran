from pathlib import Path
import tomllib

ROOT = Path(__file__).resolve().parents[1]


def test_version_and_dependencies():
    data = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    project = data["project"]
    assert project["name"] == "xyran"
    assert project["version"] == "1.0.0"
    deps = "\n".join(project["dependencies"])
    assert "pyvips[binary]" in deps
    assert "onnxruntime-gpu[cuda,cudnn]" in deps
    assert "onnxruntime>=" in deps


def test_default_contract_is_blurpad_resident_no_tiling():
    source = (ROOT / "src/xyran/moderator.py").read_text(encoding="utf-8")
    assert 'preprocess: str = "blurpad"' in source
    assert 'resident: bool = True' in source
    assert "tiling" not in source.lower()


def test_model_pin_is_exact():
    source = (ROOT / "src/xyran/model_info.py").read_text(encoding="utf-8")
    assert "23_701_765" in source
    assert "fef443ed68ae25ed693b6fef9e456071" in source
    assert "eb8b0b203952b70db191e990217174af4af39767" in source
