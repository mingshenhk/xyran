from xyran.result import ModerationScores


def test_primary_class_and_confidence():
    scores = ModerationScores(sexual=0.2, graphic=0.1, safe=0.7)
    assert scores.primary_class == "safe"
    assert scores.confidence == 0.7
