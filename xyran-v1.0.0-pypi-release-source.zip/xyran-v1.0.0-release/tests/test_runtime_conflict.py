import xyran.runtime as rt
from xyran.exceptions import RuntimeConflictError


def test_conflicting_ort_distributions_fail_closed(monkeypatch):
    monkeypatch.setattr(
        rt,
        "installed_ort_distributions",
        lambda: {"onnxruntime": "1.29.0", "onnxruntime-gpu": "1.29.0"},
    )
    try:
        rt.import_ort()
    except RuntimeConflictError:
        pass
    else:
        raise AssertionError("Expected RuntimeConflictError")
