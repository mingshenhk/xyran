from __future__ import annotations

from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
import hashlib
import shutil
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / "src" / "xyran" / "models" / "image-safety-classifier-s.onnx"
PART = DEST.with_suffix(DEST.suffix + ".part")
EXPECTED_SIZE = 23_701_765
EXPECTED_SHA256 = "fef443ed68ae25ed693b6fef9e456071692ed3963cff4168acb39c3de6f017e7"
COMMIT = "eb8b0b203952b70db191e990217174af4af39767"
REL = "onnx/image-safety-classifier-s.onnx"
URLS = [
    f"https://huggingface.co/OwenElliott/image-safety-classifier-s/resolve/{COMMIT}/{REL}?download=true",
    f"https://hf-mirror.com/OwenElliott/image-safety-classifier-s/resolve/{COMMIT}/{REL}?download=true",
    # `main` fallbacks are safe because the release builder verifies the exact
    # expected size and SHA256 before accepting the bytes.
    f"https://hf-mirror.com/OwenElliott/image-safety-classifier-s/resolve/main/{REL}?download=true",
    f"https://huggingface.co/OwenElliott/image-safety-classifier-s/resolve/main/{REL}?download=true",
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def valid(path: Path) -> bool:
    return (
        path.is_file()
        and path.stat().st_size == EXPECTED_SIZE
        and sha256(path) == EXPECTED_SHA256
    )


def download(url: str, target: Path) -> None:
    req = Request(url, headers={"User-Agent": "Xyran-release-builder/1.0"})
    with urlopen(req, timeout=45) as response, target.open("wb") as out:
        total = int(response.headers.get("Content-Length") or 0)
        done = 0
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            out.write(chunk)
            done += len(chunk)
            if total:
                print(f"  {done/1024/1024:.1f}/{total/1024/1024:.1f} MiB", end="\r")
            else:
                print(f"  {done/1024/1024:.1f} MiB", end="\r")
    print()


def main() -> int:
    DEST.parent.mkdir(parents=True, exist_ok=True)
    if valid(DEST):
        print("Pinned model already present and verified:")
        print(DEST)
        return 0

    if DEST.exists():
        print("Existing model is invalid; removing it.")
        DEST.unlink()
    if PART.exists():
        PART.unlink()

    errors = []
    for url in URLS:
        print("Downloading pinned Owen-S model:")
        print(url)
        for attempt in range(1, 4):
            try:
                if PART.exists():
                    PART.unlink()
                download(url, PART)
                size = PART.stat().st_size
                digest = sha256(PART)
                print("Size:   ", size)
                print("SHA256: ", digest)
                if size != EXPECTED_SIZE or digest != EXPECTED_SHA256:
                    raise RuntimeError(
                        "Downloaded bytes do not match the V1 release pin."
                    )
                PART.replace(DEST)
                print("Verified model saved to:")
                print(DEST)
                return 0
            except Exception as exc:
                errors.append(f"{url} attempt {attempt}: {type(exc).__name__}: {exc}")
                print(f"Attempt {attempt} failed: {exc}")
                time.sleep(min(2 * attempt, 5))

    if PART.exists():
        PART.unlink()
    print("ERROR: unable to obtain the pinned model.", file=sys.stderr)
    for err in errors:
        print(" - " + err, file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
