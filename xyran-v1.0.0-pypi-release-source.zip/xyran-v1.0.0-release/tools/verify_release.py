from __future__ import annotations

from pathlib import Path
import hashlib
import json
import sys
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"
EXPECTED_SHA256 = "fef443ed68ae25ed693b6fef9e456071692ed3963cff4168acb39c3de6f017e7"
EXPECTED_SIZE = 23_701_765
MODEL_BASENAME = "image-safety-classifier-s.onnx"


def digest_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def verify_bytes(data: bytes, origin: str):
    if len(data) != EXPECTED_SIZE:
        raise RuntimeError(
            f"{origin}: model size {len(data)} != {EXPECTED_SIZE}"
        )
    digest = digest_bytes(data)
    if digest != EXPECTED_SHA256:
        raise RuntimeError(f"{origin}: model SHA256 mismatch: {digest}")


def main() -> int:
    wheels = sorted(DIST.glob("xyran-1.0.0-*.whl"))
    sdists = sorted(DIST.glob("xyran-1.0.0.tar.gz"))
    if len(wheels) != 1 or len(sdists) != 1:
        raise RuntimeError(
            f"Expected exactly one wheel and one sdist; got {wheels}, {sdists}"
        )

    wheel = wheels[0]
    with zipfile.ZipFile(wheel) as z:
        model_names = [n for n in z.namelist() if n.endswith("/models/" + MODEL_BASENAME)]
        if len(model_names) != 1:
            raise RuntimeError(f"Wheel model entries: {model_names}")
        verify_bytes(z.read(model_names[0]), "wheel")
        metadata_names = [n for n in z.namelist() if n.endswith(".dist-info/METADATA")]
        metadata = z.read(metadata_names[0]).decode("utf-8", errors="replace")
        if "Version: 1.0.0" not in metadata:
            raise RuntimeError("Wheel metadata version is not 1.0.0")
        if "Requires-Dist: pyvips[binary]" not in metadata:
            raise RuntimeError("Wheel metadata is missing pyvips[binary]")
        if "onnxruntime-gpu" not in metadata or "onnxruntime" not in metadata:
            raise RuntimeError("Wheel metadata is missing ORT platform dependencies")

    sdist = sdists[0]
    with tarfile.open(sdist, "r:gz") as t:
        members = [m for m in t.getmembers() if m.name.endswith("/models/" + MODEL_BASENAME)]
        if len(members) != 1:
            raise RuntimeError(f"sdist model entries: {[m.name for m in members]}")
        f = t.extractfile(members[0])
        verify_bytes(f.read(), "sdist")

    print("Release verification PASS")
    print("Wheel:", wheel, wheel.stat().st_size, "bytes")
    print("sdist:", sdist, sdist.stat().st_size, "bytes")
    print("Bundled model SHA256:", EXPECTED_SHA256)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
