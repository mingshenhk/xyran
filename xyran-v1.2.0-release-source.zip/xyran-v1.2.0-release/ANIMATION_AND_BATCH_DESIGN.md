# Xyran 1.1 Animation and Batch Design

This note records the engineering contract behind Xyran 1.1's animated GIF/WebP
moderation and folder scanning.

## Goals

- never silently treat a multi-frame file as a single still image;
- preserve the frame a viewer would actually see, including animation composition;
- reduce model calls on long animations without pretending a sample is exhaustive;
- keep an explicit exhaustive mode;
- batch selected frames through the model's dynamic batch dimension;
- bound hostile/accidental resource use;
- make folder scans reproducible and exportable.

## Decoder split

Xyran uses Pillow's sequence API for GIF/WebP animation traversal because it
exposes `n_frames`, `seek()`, frame duration/timestamp metadata and decoded
display frames. Selected display frames are then sent through the same pyvips
preprocessing pipeline used for still images.

libvips/pyvips remains the main preprocessing backend. It also exposes
multi-page/page-count APIs and page-aware GIF/WebP loaders, which are useful for
fail-closed checks and future optimizations.

## Smart sampler

The sampler is deterministic. For long animations, the default 32-frame budget
is split across complementary signals:

- first and last frame;
- playback-time coverage using real/effective frame durations;
- highest adjacent-frame visual-change scores from 48x48 RGB signatures, combining global change with the most-changed local regions;
- longest-dwell frames;
- deterministic coverage fill when candidate sets collide.

Animations at or below the sample budget are exhaustive automatically.
`sampling="all"` scans every frame up to hard source limits.

The visual-change pass is a cheap *selection heuristic*, not a safety model. It
must never be described as guaranteeing that an unsafe frame is found.

## Result semantics

Every sampled frame gets ordinary Owen-S probabilities and an ordinary Xyran
policy decision. The animation decision is the worst sampled frame by policy
severity, then risk score.

`worst_frame.scores` is a real three-class model output.

`peak_scores` is intentionally an aggregate convenience field:

- sexual = maximum sampled sexual score;
- graphic = maximum sampled graphic score;
- safe = minimum sampled safe score.

Therefore `peak_scores` is not required to sum to 1.

## Hard limits

Defaults:

- 5,000 source frames;
- 600,000 ms effective animation duration;
- 80,000,000 pixels per displayed frame;
- 32 model-scanned frames in smart mode;
- 16 frames per ONNX batch.

These are runtime safety limits, not moderation thresholds.

## Folder scanning

Known image extensions are discovered by default. Static files are grouped into
true ONNX batches. Animated GIF/WebP files are analyzed independently so their
temporal metadata and bounded frame memory stay isolated, while sampled frames
inside each animation are still sent in ONNX batches.

A grouped static batch that contains a problematic file falls back to per-file
processing so one corrupt input does not erase results for the rest of the
folder.

Reports are generated atomically in JSON, Markdown, TXT and CSV. JSON preserves
full structured animation evidence; CSV is deliberately flattened to one row per
file using the worst sampled animation frame.

## Known non-goals for 1.1

- APNG frame-aware moderation;
- animated AVIF/HEIF frame-aware moderation;
- video containers (MP4/WebM/MOV);
- cross-file GPU super-batching of frames from multiple animations;
- optical-flow or learned scene detection;
- claims of exhaustive safety when smart sampling is used.
