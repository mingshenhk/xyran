@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"

echo ============================================================
echo   Xyran V1.2.0 - PyPI Release Builder
echo ============================================================
echo.

if not exist ".release-venv\Scripts\python.exe" (
  echo [1/7] Creating release environment...
  python -m venv .release-venv || goto :FAIL
)

call ".release-venv\Scripts\activate.bat" || goto :FAIL

echo [2/7] Installing build/test tools...
python -m pip install --upgrade pip || goto :FAIL
python -m pip install build twine pytest numpy Pillow packaging || goto :FAIL

echo [3/7] Downloading/verifying pinned bundled model...
python tools\prepare_model.py || goto :FAIL

echo [4/7] Running unit/regression tests...
set "PYTHONPATH=%CD%\src"
python -m pytest -q || goto :FAIL
set "PYTHONPATH="

echo [5/7] Cleaning previous build output...
if exist dist rmdir /s /q dist
if exist build rmdir /s /q build
for /d %%D in (src\*.egg-info) do rmdir /s /q "%%D"

echo [6/7] Building wheel and sdist...
python -m build || goto :FAIL
python -m twine check dist\* || goto :FAIL

echo [7/7] Verifying model is physically inside both archives...
python tools\verify_release.py || goto :FAIL

echo.
echo ============================================================
echo [SUCCESS] PyPI artifacts are ready in dist\
echo.
dir dist
echo.
echo Next recommended step:
echo   TEST_LOCAL_INSTALL.bat
echo Then upload with:
echo   .release-venv\Scripts\python -m twine upload dist\*
echo ============================================================
exit /b 0

:FAIL
echo.
echo ============================================================
echo [FAILED] Release build stopped. Nothing should be uploaded.
echo ============================================================
exit /b 1
