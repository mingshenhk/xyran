# Changelog

## 1.2.0

- Added `xyran repair-runtime`.
- Detects and removes overlapping ONNX Runtime distributions.
- Repairs damaged shared `onnxruntime` namespaces by reinstalling one clean runtime.
- Uses `sys.executable -m pip` so the active Xyran Python environment is repaired.
- Added `--dry-run`, `--yes`, `--runtime auto|cpu|gpu`, and JSON output.
- Verifies repaired runtime in a fresh Python process.
- Runs bundled-model and dynamic-batch smoke tests after repair.
- `xyran doctor` now points directly to the repair command on runtime failure.
- Retains all 1.1.x animated GIF/WebP, smart sampling, true batching,
  folder scanning and JSON/Markdown/TXT/CSV reporting features.

## 1.2.0

- Added frame-aware animated GIF moderation.
- Added frame-aware animated WebP moderation.
- Added deterministic smart animation sampling with endpoints, duration-aware
  temporal coverage, visual-change peaks, long-dwell frames and coverage fill.
- Added exhaustive `sampling="all"` mode.
- Added real dynamic ONNX batching for selected animation frames.
- Upgraded `scan_batch()` to true ONNX batching for static images.
- Added automatic animation dispatch in `Moderator.scan()`.
- Added recursive `Moderator.scan_folder()`.
- Added JSON, Markdown, TXT and CSV folder reports.
- Added `xyran scan-animation` and `xyran scan-folder` CLI commands.
- Added animation resource limits and explicit exhaustive/sampled metadata.
- Kept non-GIF/WebP multi-page formats fail-closed.
- Made Pillow-origin transparency flatten to white, matching the libvips path.

## 1.0.1

- Formalized static multi-format image support.
- Added content-signature format identification and `xyran formats`.
- Added explicit multi-frame rejection instead of silently scanning frame 0.

## 1.0.0

- First public Xyran release.
- Bundled pinned Owen-S ONNX model.
- BlurPad + Lanczos3 default preprocessing.
- Local CUDA/CPU ONNX Runtime inference with runtime diagnostics.
