# Xyran Runtime Repair Design

## Why this exists

The Python distributions `onnxruntime` and `onnxruntime-gpu` are separate
packages from pip's point of view, but both write the same import namespace:
`site-packages/onnxruntime/`.

That creates two real failure modes:

1. a pre-existing CPU ORT and Xyran's GPU ORT coexist;
2. uninstalling only one distribution deletes files the other distribution
   also relies on, leaving a damaged namespace.

`xyran repair-runtime` solves this by removing every ORT variant first and
installing exactly one clean runtime.

## Safety rules

- Never invoke a bare `pip`; use `sys.executable -m pip`.
- Never modify an environment without confirmation unless `--yes` is supplied.
- `--dry-run` performs no package changes.
- The command does not attempt in-process ORT verification after package
  mutation; it starts a fresh Python process.
- Verification includes:
  - installed distribution count;
  - ONNX Runtime import integrity;
  - provider enumeration;
  - CUDA/cuDNN preload where applicable;
  - bundled Owen-S model load;
  - real single-image inference smoke;
  - real dynamic-batch inference smoke.
- If reinstall fails, report that ORT may be temporarily absent and provide a
  safe retry path.

## Runtime selection

`--runtime auto`:
- Windows AMD64/x86_64: GPU runtime
- Linux x86_64/AMD64: GPU runtime
- other supported platforms: CPU runtime

Explicit `--runtime gpu` rejects unsupported platforms rather than pretending
to repair successfully.
