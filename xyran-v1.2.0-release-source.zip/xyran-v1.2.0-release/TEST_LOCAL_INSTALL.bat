@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"

if not exist "dist\xyran-1.2.0-py3-none-any.whl" (
  echo ERROR: built wheel not found. Run BUILD_RELEASE.bat first.
  exit /b 1
)

if exist .install-test rmdir /s /q .install-test
if exist _xyran_smoke_media rmdir /s /q _xyran_smoke_media
for %%F in (_xyran_smoke_report.json _xyran_smoke_report.md _xyran_smoke_report.txt _xyran_smoke_report.csv) do del /q "%%F" >nul 2>nul

python -m venv .install-test || exit /b 1
call .install-test\Scripts\activate.bat || exit /b 1
python -m pip install --upgrade pip || exit /b 1
python -m pip install dist\xyran-1.2.0-py3-none-any.whl || exit /b 1

echo.
echo ============================================================
echo [1/6] Running end-user doctor test...
echo ============================================================
xyran doctor || exit /b 1

echo.
echo ============================================================
echo [2/6] Checking format capabilities...
echo ============================================================
xyran formats
if errorlevel 1 exit /b 1

xyran repair-runtime --dry-run || exit /b 1

echo.
echo ============================================================
echo [3/6] Creating static + animated smoke media...
echo ============================================================
python tools\create_smoke_media.py || exit /b 1

echo.
echo ============================================================
echo [4/6] Static image + auto animated GIF scan...
echo ============================================================
xyran scan _xyran_smoke_media\static.png --json || exit /b 1
xyran scan _xyran_smoke_media\animated.gif --json || exit /b 1

echo.
echo ============================================================
echo [5/6] Exhaustive GIF animation scan...
echo ============================================================
xyran scan-animation _xyran_smoke_media\animated.gif --sampling all --json || exit /b 1
if exist _xyran_smoke_media\animated.webp (
  echo.
  echo Testing animated WebP...
  xyran scan-animation _xyran_smoke_media\animated.webp --sampling all --json || exit /b 1
)

echo.
echo ============================================================
echo [6/6] Recursive folder scan + JSON/MD/TXT/CSV reports...
echo ============================================================
xyran scan-folder _xyran_smoke_media --output _xyran_smoke_report --report-formats json md txt csv || exit /b 1

if not exist _xyran_smoke_report.json exit /b 1
if not exist _xyran_smoke_report.md exit /b 1
if not exist _xyran_smoke_report.txt exit /b 1
if not exist _xyran_smoke_report.csv exit /b 1

echo.
echo [SUCCESS] Clean install, static scan, animated GIF, batching, folder scan and reports passed.
exit /b 0
