from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
from time import perf_counter
from typing import Literal

import numpy as np
from PIL import Image, ImageOps, UnidentifiedImageError

from .exceptions import InvalidImageError, UnsupportedImageFormatError
from .preprocess import DEFAULT_MAX_PIXELS, ImageInput

AnimationSampling = Literal["smart", "uniform", "all"]
SUPPORTED_ANIMATION_FORMATS = frozenset({"GIF", "WEBP"})
DEFAULT_ANIMATION_SAMPLES = 32
DEFAULT_ANIMATION_BATCH_SIZE = 16
DEFAULT_MAX_SOURCE_FRAMES = 5_000
DEFAULT_MAX_DURATION_MS = 600_000
DEFAULT_FRAME_DURATION_MS = 100
SIGNATURE_SIZE = 48


@dataclass(frozen=True)
class AnimationFrameMeta:
    index: int
    timestamp_ms: int
    duration_ms: int
    change_score: float


@dataclass(frozen=True)
class AnimationProbe:
    source_format: str
    width: int
    height: int
    frame_count: int
    duration_ms: int
    loop: int | None
    is_animated: bool


@dataclass(frozen=True)
class AnimationAnalysis:
    probe: AnimationProbe
    frames: tuple[AnimationFrameMeta, ...]
    selected_indices: tuple[int, ...]
    selection_reasons: dict[int, tuple[str, ...]]
    sampling: AnimationSampling
    exhaustive: bool
    analysis_ms: float


@contextmanager
def _open_pillow(source: ImageInput):
    owned = False
    original_position = None
    stream = None

    try:
        if isinstance(source, Image.Image):
            image = source
            try:
                original_position = image.tell()
            except Exception:
                original_position = None
        elif isinstance(source, (bytes, bytearray)):
            stream = BytesIO(bytes(source))
            image = Image.open(stream)
            owned = True
        else:
            image = Image.open(Path(source))
            owned = True

        yield image
    except (UnsupportedImageFormatError, InvalidImageError):
        raise
    except (OSError, ValueError, UnidentifiedImageError) as exc:
        raise InvalidImageError(f"Unable to decode animation: {exc}") from exc
    finally:
        if owned:
            try:
                image.close()
            except Exception:
                pass
        elif original_position is not None:
            try:
                image.seek(original_position)
            except Exception:
                pass
        if stream is not None:
            stream.close()


def _normalize_duration(value) -> int:
    try:
        duration = int(round(float(value)))
    except (TypeError, ValueError, OverflowError):
        duration = 0
    return duration if duration > 0 else DEFAULT_FRAME_DURATION_MS


def _frame_signature(image: Image.Image) -> np.ndarray:
    # The signature is intentionally cheap. It is used only to rank visual
    # changes for sampling; moderation still uses the full composited frame.
    rgb = image.convert("RGB")
    thumb = rgb.resize((SIGNATURE_SIZE, SIGNATURE_SIZE), Image.Resampling.BILINEAR)
    return np.asarray(thumb, dtype=np.int16)


def _change_score(previous: np.ndarray | None, current: np.ndarray) -> float:
    if previous is None:
        return 1.0
    # Blend global change with the most-changed 5% of thumbnail pixels. The
    # local term makes a small but abrupt inserted region more visible to the
    # sampler than a plain whole-frame mean would, without turning this into a
    # learned safety detector.
    per_pixel = np.abs(current - previous).mean(axis=2).astype(np.float32) / 255.0
    global_mean = float(per_pixel.mean())
    flat = per_pixel.reshape(-1)
    top_k = max(1, int(round(flat.size * 0.05)))
    local_peak = float(np.partition(flat, flat.size - top_k)[-top_k:].mean())
    return 0.35 * global_mean + 0.65 * local_peak


def _nearest_frame_for_time(frames: tuple[AnimationFrameMeta, ...], target_ms: float) -> int:
    # Compare against each frame midpoint so long-dwell frames naturally get
    # more temporal representation than very short transitional frames.
    return min(
        frames,
        key=lambda f: abs((f.timestamp_ms + f.duration_ms / 2.0) - target_ms),
    ).index


def _even_frame_indices(frame_count: int, count: int) -> list[int]:
    if count <= 0 or frame_count <= 0:
        return []
    if count >= frame_count:
        return list(range(frame_count))
    return sorted(set(int(round(x)) for x in np.linspace(0, frame_count - 1, count)))


def select_animation_frames(
    frames: tuple[AnimationFrameMeta, ...],
    *,
    sampling: AnimationSampling = "smart",
    max_samples: int = DEFAULT_ANIMATION_SAMPLES,
) -> tuple[tuple[int, ...], dict[int, tuple[str, ...]], bool]:
    if sampling not in {"smart", "uniform", "all"}:
        raise ValueError("sampling must be one of: smart, uniform, all")
    if max_samples <= 0:
        raise ValueError("max_samples must be > 0")
    if not frames:
        raise InvalidImageError("Animation contains no frames")

    frame_count = len(frames)
    if sampling == "all" or frame_count <= max_samples:
        reasons = {
            frame.index: (("all",) if sampling == "all" else ("short_animation",))
            for frame in frames
        }
        return tuple(frame.index for frame in frames), reasons, True

    budget = min(max_samples, frame_count)
    reasons_mut: dict[int, set[str]] = {}

    def add(index: int, reason: str) -> None:
        reasons_mut.setdefault(index, set()).add(reason)

    if budget == 1:
        # A caller explicitly requested a single sample. Prefer the strongest
        # visual-change candidate; this is deterministic but intentionally less
        # safe than the default multi-sample budget.
        chosen = max(frames, key=lambda f: (f.change_score, f.duration_ms, -f.index))
        return (chosen.index,), {chosen.index: ("single_budget",)}, False

    # Endpoints prevent missing intro/outro content.
    add(0, "endpoint")
    add(frame_count - 1, "endpoint")

    if sampling == "uniform":
        for index in _even_frame_indices(frame_count, budget):
            add(index, "uniform_frame")
    else:
        # Smart sampling deliberately combines three signals:
        # 1) time coverage weighted by real frame durations,
        # 2) visual-change peaks,
        # 3) long-dwell frames.
        remaining = max(0, budget - 2)
        temporal_count = int(round(remaining * 0.55))
        change_count = int(round(remaining * 0.30))
        dwell_count = max(0, remaining - temporal_count - change_count)

        total_duration = sum(frame.duration_ms for frame in frames)
        if temporal_count == 1:
            targets = [total_duration / 2.0]
        elif temporal_count > 1:
            targets = np.linspace(0, max(0, total_duration - 1), temporal_count)
        else:
            targets = []
        for target in targets:
            add(_nearest_frame_for_time(frames, float(target)), "time_coverage")

        # Frame 0 has a synthetic change score of 1.0, but it is already an
        # endpoint, so exclude it from change ranking.
        for frame in sorted(frames[1:], key=lambda f: (f.change_score, -f.index), reverse=True)[:change_count]:
            add(frame.index, "visual_change")

        for frame in sorted(frames, key=lambda f: (f.duration_ms, -f.index), reverse=True)[:dwell_count]:
            add(frame.index, "long_dwell")

        # Collisions between the three signal sets are common. Fill remaining
        # budget with deterministic frame-uniform coverage rather than random
        # picks so reports are reproducible.
        if len(reasons_mut) < budget:
            for index in _even_frame_indices(frame_count, budget * 2):
                if len(reasons_mut) >= budget:
                    break
                add(index, "coverage_fill")

        if len(reasons_mut) < budget:
            for index in range(frame_count):
                if len(reasons_mut) >= budget:
                    break
                add(index, "coverage_fill")

    # If uniform mode had duplicate rounded positions, fill deterministically.
    if len(reasons_mut) < budget:
        for index in range(frame_count):
            if len(reasons_mut) >= budget:
                break
            add(index, "coverage_fill")

    if len(reasons_mut) > budget:
        reason_weight = {
            "endpoint": 5,
            "visual_change": 4,
            "time_coverage": 3,
            "long_dwell": 2,
            "coverage_fill": 1,
            "uniform_frame": 1,
        }
        ranked = sorted(
            reasons_mut,
            key=lambda index: (
                max(reason_weight.get(r, 0) for r in reasons_mut[index]),
                len(reasons_mut[index]),
                frames[index].change_score,
                frames[index].duration_ms,
                -index,
            ),
            reverse=True,
        )[:budget]
        selected = tuple(sorted(ranked))
    else:
        selected = tuple(sorted(reasons_mut))
    reasons = {index: tuple(sorted(reasons_mut[index])) for index in selected}
    return selected, reasons, False


def analyze_animation(
    source: ImageInput,
    *,
    sampling: AnimationSampling = "smart",
    max_samples: int = DEFAULT_ANIMATION_SAMPLES,
    max_source_frames: int = DEFAULT_MAX_SOURCE_FRAMES,
    max_duration_ms: int = DEFAULT_MAX_DURATION_MS,
    max_pixels: int = DEFAULT_MAX_PIXELS,
) -> AnimationAnalysis:
    start = perf_counter()
    if max_source_frames <= 0:
        raise ValueError("max_source_frames must be > 0")
    if max_duration_ms <= 0:
        raise ValueError("max_duration_ms must be > 0")

    with _open_pillow(source) as image:
        source_format = str(getattr(image, "format", "") or "").upper()
        if source_format not in SUPPORTED_ANIMATION_FORMATS:
            raise UnsupportedImageFormatError(
                f"Animated scanning currently supports GIF and WebP; got {source_format or 'UNKNOWN'}."
            )

        frame_count = max(1, int(getattr(image, "n_frames", 1)))
        width, height = map(int, image.size)
        if width <= 0 or height <= 0:
            raise InvalidImageError("Animation dimensions must be positive")
        if width * height > max_pixels:
            raise InvalidImageError(
                f"Animation frame too large: {width}x{height} = {width*height:,} pixels; "
                f"limit is {max_pixels:,}."
            )
        if frame_count > max_source_frames:
            raise InvalidImageError(
                f"Animation has {frame_count:,} frames; hard limit is {max_source_frames:,}."
            )

        loop = image.info.get("loop")
        try:
            loop = int(loop) if loop is not None else None
        except (TypeError, ValueError):
            loop = None

        metas: list[AnimationFrameMeta] = []
        previous_signature = None
        timestamp = 0

        for index in range(frame_count):
            image.seek(index)
            # WebP sets timestamp/duration while loading the selected frame.
            image.load()
            duration = _normalize_duration(image.info.get("duration"))
            signature = _frame_signature(image)
            change = _change_score(previous_signature, signature)
            metas.append(
                AnimationFrameMeta(
                    index=index,
                    timestamp_ms=timestamp,
                    duration_ms=duration,
                    change_score=round(change, 6),
                )
            )
            previous_signature = signature
            timestamp += duration
            if timestamp > max_duration_ms:
                raise InvalidImageError(
                    f"Animation duration exceeds hard limit of {max_duration_ms:,} ms."
                )

        frames = tuple(metas)
        selected, reasons, exhaustive = select_animation_frames(
            frames,
            sampling=sampling,
            max_samples=max_samples,
        )

        probe = AnimationProbe(
            source_format=source_format,
            width=width,
            height=height,
            frame_count=frame_count,
            duration_ms=timestamp,
            loop=loop,
            is_animated=frame_count > 1,
        )

    return AnimationAnalysis(
        probe=probe,
        frames=frames,
        selected_indices=selected,
        selection_reasons=reasons,
        sampling=sampling,
        exhaustive=exhaustive,
        analysis_ms=round((perf_counter() - start) * 1000.0, 4),
    )


def extract_selected_frames(
    source: ImageInput,
    analysis: AnimationAnalysis,
) -> list[tuple[AnimationFrameMeta, Image.Image]]:
    selected = set(analysis.selected_indices)
    output: list[tuple[AnimationFrameMeta, Image.Image]] = []
    meta_by_index = {meta.index: meta for meta in analysis.frames}

    with _open_pillow(source) as image:
        source_format = str(getattr(image, "format", "") or "").upper()
        if source_format != analysis.probe.source_format:
            raise InvalidImageError("Animation format changed between analysis and extraction")

        for index in analysis.selected_indices:
            image.seek(index)
            image.load()
            # Pillow's sequence decoders expose the display frame after applying
            # the format's sequencing/composition rules. Copy it so later seek()
            # calls cannot mutate the selected frame.
            frame = ImageOps.exif_transpose(image).convert("RGBA").copy()
            frame.format = source_format
            output.append((meta_by_index[index], frame))

    return output


def probe_media(source: ImageInput, *, max_pixels: int = DEFAULT_MAX_PIXELS) -> AnimationProbe:
    """Cheap media probe used by scan() auto-dispatch and folder scanning."""
    with _open_pillow(source) as image:
        fmt = str(getattr(image, "format", "") or "").upper()
        width, height = map(int, image.size)
        if width <= 0 or height <= 0:
            raise InvalidImageError("Image dimensions must be positive")
        if width * height > max_pixels:
            raise InvalidImageError(
                f"Image too large: {width}x{height} = {width*height:,} pixels; limit is {max_pixels:,}."
            )
        frame_count = max(1, int(getattr(image, "n_frames", 1)))
        loop = image.info.get("loop")
        try:
            loop = int(loop) if loop is not None else None
        except (TypeError, ValueError):
            loop = None

        # Avoid a full duration pass in the cheap probe. Animation scanning will
        # calculate exact effective duration during analyze_animation().
        return AnimationProbe(
            source_format=fmt,
            width=width,
            height=height,
            frame_count=frame_count,
            duration_ms=0,
            loop=loop,
            is_animated=frame_count > 1,
        )
