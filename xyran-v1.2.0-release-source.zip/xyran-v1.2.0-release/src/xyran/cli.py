from __future__ import annotations

import argparse
import json
import platform
import subprocess
import sys
from pathlib import Path

from . import __version__
from .animation import (
    DEFAULT_ANIMATION_BATCH_SIZE,
    DEFAULT_ANIMATION_SAMPLES,
    DEFAULT_MAX_DURATION_MS,
    DEFAULT_MAX_SOURCE_FRAMES,
)
from .exceptions import XyranError
from .formats import format_diagnostics
from .model_info import resolve_model_path, verify_bundled_model
from .moderator import Moderator
from .preprocess import pyvips_diagnostics
from .result import AnimationModerationResult, ModerationResult
from .runtime import runtime_diagnostics
from .runtime_repair import build_repair_plan, repair_runtime


def _add_runtime_options(p: argparse.ArgumentParser) -> None:
    p.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto")
    p.add_argument("--preprocess", choices=["blurpad", "warp"], default="blurpad")
    p.add_argument(
        "--resident",
        action=argparse.BooleanOptionalAction,
        default=True,
    )


def _add_animation_options(p: argparse.ArgumentParser, *, prefix: str = "") -> None:
    dest_prefix = prefix.replace("-", "_")
    opt_prefix = (prefix + "-") if prefix else ""
    p.add_argument(
        f"--{opt_prefix}sampling",
        dest=f"{dest_prefix}sampling" if dest_prefix else "sampling",
        choices=["smart", "uniform", "all"],
        default="smart",
        help="smart=time coverage + visual-change peaks + dwell; all=exhaustive",
    )
    p.add_argument(
        f"--{opt_prefix}max-samples",
        dest=f"{dest_prefix}max_samples" if dest_prefix else "max_samples",
        type=int,
        default=DEFAULT_ANIMATION_SAMPLES,
    )
    p.add_argument(
        f"--{opt_prefix}batch-size",
        dest=f"{dest_prefix}batch_size" if dest_prefix else "batch_size",
        type=int,
        default=DEFAULT_ANIMATION_BATCH_SIZE,
    )
    p.add_argument(
        f"--{opt_prefix}max-source-frames",
        dest=f"{dest_prefix}max_source_frames" if dest_prefix else "max_source_frames",
        type=int,
        default=DEFAULT_MAX_SOURCE_FRAMES,
    )
    p.add_argument(
        f"--{opt_prefix}max-duration-ms",
        dest=f"{dest_prefix}max_duration_ms" if dest_prefix else "max_duration_ms",
        type=int,
        default=DEFAULT_MAX_DURATION_MS,
    )


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="xyran")
    p.add_argument("--version", action="version", version=__version__)
    sub = p.add_subparsers(dest="command", required=True)

    scan = sub.add_parser("scan", help="Moderate one image or animated GIF/WebP")
    scan.add_argument("image")
    _add_runtime_options(scan)
    scan.add_argument("--animation-sampling", choices=["smart", "uniform", "all"], default="smart")
    scan.add_argument("--animation-max-samples", type=int, default=DEFAULT_ANIMATION_SAMPLES)
    scan.add_argument("--animation-batch-size", type=int, default=DEFAULT_ANIMATION_BATCH_SIZE)
    scan.add_argument("--json", action="store_true")

    animation = sub.add_parser("scan-animation", help="Moderate one animated GIF/WebP")
    animation.add_argument("animation")
    _add_runtime_options(animation)
    _add_animation_options(animation)
    animation.add_argument("--json", action="store_true")

    folder = sub.add_parser("scan-folder", help="Moderate a directory and write reports")
    folder.add_argument("folder")
    _add_runtime_options(folder)
    folder.add_argument(
        "--recursive",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="scan subdirectories (default: true)",
    )
    folder.add_argument("--batch-size", type=int, default=DEFAULT_ANIMATION_BATCH_SIZE)
    folder.add_argument("--animation-sampling", choices=["smart", "uniform", "all"], default="smart")
    folder.add_argument("--animation-max-samples", type=int, default=DEFAULT_ANIMATION_SAMPLES)
    folder.add_argument("--animation-batch-size", type=int, default=DEFAULT_ANIMATION_BATCH_SIZE)
    folder.add_argument("--probe-unknown", action="store_true")
    folder.add_argument(
        "--output",
        default="xyran-report",
        help="report path stem; default: ./xyran-report",
    )
    folder.add_argument(
        "--report-formats",
        nargs="+",
        choices=["json", "md", "txt", "csv"],
        default=["json", "md", "txt"],
    )
    folder.add_argument("--json", action="store_true", help="also print folder result JSON to stdout")

    formats = sub.add_parser("formats", help="Show local image-format support")
    formats.add_argument("--json", action="store_true")

    doctor = sub.add_parser("doctor", help="Inspect local model/runtime readiness")
    doctor.add_argument("--json", action="store_true")

    repair = sub.add_parser(
        "repair-runtime",
        help="Repair conflicting or damaged ONNX Runtime installations",
    )
    repair.add_argument(
        "--runtime",
        choices=["auto", "cpu", "gpu"],
        default="auto",
        help="runtime to reinstall; auto uses GPU on Windows/Linux x64, CPU elsewhere",
    )
    repair.add_argument(
        "--dry-run",
        action="store_true",
        help="show the exact repair plan without changing the environment",
    )
    repair.add_argument(
        "--yes",
        action="store_true",
        help="do not ask for interactive confirmation",
    )
    repair.add_argument("--json", action="store_true")
    return p


def repair_runtime_cli(
    *,
    requested_runtime: str,
    dry_run: bool,
    assume_yes: bool,
    as_json: bool,
) -> int:
    try:
        plan = build_repair_plan(requested_runtime)
    except Exception as exc:
        if as_json:
            print(json.dumps({
                "status": "FAILED",
                "error": f"{type(exc).__name__}: {exc}",
            }, ensure_ascii=False, indent=2))
        else:
            print(f"error: {exc}", file=sys.stderr)
        return 1

    if not as_json:
        print(f"Xyran Runtime Repair  {__version__}")
        print(f"Python                {plan.python}")
        print(f"Platform              {plan.platform} / {plan.machine}")
        print(f"Selected runtime      {plan.selected_runtime.upper()}")
        print(f"Target                {plan.target_spec}")
        print("")
        if plan.installed_before:
            print("Detected")
            for name, version in sorted(plan.installed_before.items()):
                print(f"  {name:<24} {version}")
        else:
            print("Detected               no ONNX Runtime distribution")
        print("")
        print("Uninstall command")
        print("  " + subprocess.list2cmdline(plan.uninstall_command))
        print("Install command")
        print("  " + subprocess.list2cmdline(plan.install_command))
        print("")

    result = repair_runtime(
        requested_runtime=requested_runtime,
        dry_run=dry_run,
        assume_yes=assume_yes,
    )
    payload = result.to_dict()

    if as_json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        if result.status == "DRY_RUN":
            print("Dry run only. No packages were changed.")
        elif result.status == "CANCELLED":
            print("Runtime repair cancelled.")
        elif result.status == "READY":
            verification = result.verification or {}
            runtime = verification.get("runtime") or {}
            print("")
            print("Removing ORT variants  PASS")
            print("Installing runtime     PASS")
            print("Fresh-process verify   PASS")
            if runtime.get("version"):
                print(f"ONNX Runtime          {runtime['version']}")
            if runtime.get("available_providers"):
                print("Providers             " + ", ".join(runtime["available_providers"]))
            if runtime.get("cuda_preload"):
                print(f"CUDA DLL preload      {runtime['cuda_preload']}")
            if runtime.get("active_provider"):
                print(f"Active provider       {runtime['active_provider']}")
            if runtime.get("smoke_test"):
                print(f"Runtime smoke test    {runtime['smoke_test']}")
            if runtime.get("batch_smoke_test"):
                print(f"Dynamic batch smoke   {runtime['batch_smoke_test']}")
            print("")
            print("Overall               READY")
            print("Xyran runtime repaired successfully.")
        else:
            print("")
            print("Runtime repair        FAILED")
            if result.error:
                print(f"Reason                {result.error}")
            print(
                "Run `xyran repair-runtime --dry-run` to inspect the plan, "
                "then retry when package/network access is available."
            )

    if result.status in {"DRY_RUN", "CANCELLED", "READY"}:
        return 0
    return 1


def show_formats(as_json: bool) -> int:
    report = format_diagnostics()

    if as_json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0

    print(f"Xyran image formats    {__version__}")
    print("")
    print("Raster inputs")
    for row in report["formats"]:
        extensions = ", ".join(row["extensions"])
        state = "READY" if row["available"] else "UNAVAILABLE"
        backends = "/".join(row["backends"]) if row["backends"] else "-"
        policy = row["multiframe_policy"]
        print(f"{row['name']:<12} {extensions:<35} {state:<11} {backends:<18} {policy}")

    print("")
    print(f"Animated GIF           {report['animated_gif']}")
    print(f"Animated WebP          {report['animated_webp']}")
    print("Default animation      SMART, max 32 sampled frames")
    print("Exhaustive animation   --animation-sampling all / scan-animation --sampling all")
    print("Other multi-page       REJECTED")
    print("SVG                    NOT SUPPORTED")
    print("PDF                    NOT SUPPORTED")
    return 0


def doctor(as_json: bool) -> int:
    try:
        model_path, bundled = resolve_model_path(None)
        model = verify_bundled_model(str(model_path))
        model_status = "OK"
        model_error = None
    except Exception as exc:
        model_path = None
        bundled = True
        model = None
        model_status = "ERROR"
        model_error = f"{type(exc).__name__}: {exc}"

    runtime = runtime_diagnostics(model_path) if model_path else {
        "status": "NOT_TESTED",
        "error": "Model unavailable",
    }
    vips = pyvips_diagnostics()

    ready = (
        model_status == "OK"
        and runtime.get("status") == "READY"
        and vips.get("available") is True
    )

    payload = {
        "sdk_version": __version__,
        "python_version": platform.python_version(),
        "model_status": model_status,
        "model": model,
        "model_error": model_error,
        "runtime": runtime,
        "image_backend": vips,
        "defaults": {
            "preprocess": "blurpad_lanczos3",
            "tiling": False,
            "resident": True,
            "device": "auto",
            "animation_sampling": "smart",
            "animation_max_samples": DEFAULT_ANIMATION_SAMPLES,
            "animation_batch_size": DEFAULT_ANIMATION_BATCH_SIZE,
            "folder_report_formats": ["json", "md", "txt"],
        },
        "capabilities": {
            "animated_gif": True,
            "animated_webp": True,
            "folder_scan": True,
            "true_onnx_batching": True,
            "reports": ["json", "md", "txt", "csv"],
            "runtime_repair": True,
        },
        "privacy": {
            "telemetry": False,
            "cloud_api": False,
            "network_required_for_inference": False,
        },
        "overall": "READY" if ready else "NOT_READY",
    }

    if as_json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0 if ready else 1

    print(f"Xyran V1    {__version__}")
    print(f"Python                {payload['python_version']}")
    print("")
    print(f"Model                 {'BUNDLED / VERIFIED' if model_status == 'OK' else 'ERROR'}")
    if model:
        print(f"Model bytes           {model['size_bytes']}")
        print(f"Model SHA256          {model['sha256'][:16]}...")
    if model_error:
        print(f"Model error           {model_error}")
    print("")
    print(f"pyvips                {vips.get('version') if vips.get('available') else 'UNAVAILABLE'}")
    print("Default preprocess    BlurPad + Lanczos3")
    print("Optional preprocess   Warp + Linear")
    print("Tiling                OFF")
    print("Model resident        YES")
    print("Animated GIF/WebP     SMART / ALL")
    print("Folder scan           YES")
    print("Reports               JSON / MD / TXT / CSV")
    print("")
    print(f"Runtime status        {runtime.get('status')}")
    if runtime.get("version"):
        print(f"ONNX Runtime          {runtime['version']}")
    if runtime.get("available_providers"):
        print("Providers             " + ", ".join(runtime["available_providers"]))
    if runtime.get("cuda_preload"):
        print(f"CUDA DLL preload      {runtime['cuda_preload']}")
    if runtime.get("active_provider"):
        print(f"Active provider       {runtime['active_provider']}")
    if runtime.get("smoke_test"):
        print(f"Runtime smoke test    {runtime['smoke_test']}")
    if runtime.get("batch_smoke_test"):
        print(f"Dynamic batch smoke   {runtime['batch_smoke_test']}")
    if runtime.get("error"):
        print(f"Runtime error         {runtime['error']}")
        print("Suggested repair      xyran repair-runtime")
    print("")
    print("Telemetry             DISABLED")
    print("Cloud API             NONE")
    print("Inference             LOCAL")
    print("Network for inference NO")
    print(f"Overall               {'READY' if ready else 'NOT READY'}")
    return 0 if ready else 1


def _print_static(result: ModerationResult) -> None:
    p = result.processing
    print(result.decision)
    print(f"sexual   {result.scores.sexual:.4f}")
    print(f"graphic  {result.scores.graphic:.4f}")
    print(f"safe     {result.scores.safe:.4f}")
    print(f"provider {result.provider}")
    print(f"fallback {result.runtime_fallback}")
    print(f"image    {p.original_width}x{p.original_height}")
    print(f"format   {p.source_format or '-'}")
    print(f"prep     {p.preprocess}")
    print(f"resident {p.model_resident}")
    print(f"prep_ms  {p.preprocess_ms:.3f}")
    print(f"infer_ms {p.inference_ms:.3f}")
    print(f"total_ms {p.total_ms:.3f}")
    for warning in result.warnings:
        print(f"warning  {warning}")


def _print_animation(result: AnimationModerationResult) -> None:
    p = result.processing
    worst = result.worst_frame
    print(result.decision)
    print(f"type       animation/{p.source_format.lower()}")
    print(f"frames     {p.sampled_frames}/{p.total_frames}")
    print(f"sampling   {p.sampling}")
    print(f"exhaustive {p.exhaustive}")
    print(f"duration   {p.total_duration_ms} ms")
    print(f"worst      frame {worst.frame_index} @ {worst.timestamp_ms} ms")
    print(f"sexual     {worst.scores.sexual:.4f}")
    print(f"graphic    {worst.scores.graphic:.4f}")
    print(f"safe       {worst.scores.safe:.4f}")
    print(f"provider   {result.provider}")
    print(f"batch      {p.batch_size}")
    print(f"analysis_ms {p.analysis_ms:.3f}")
    print(f"prep_ms     {p.preprocess_ms:.3f}")
    print(f"infer_ms    {p.inference_ms:.3f}")
    print(f"total_ms    {p.total_ms:.3f}")
    for warning in result.warnings:
        print(f"warning    {warning}")


def _new_moderator(args) -> Moderator:
    return Moderator(
        device=args.device,
        preprocess=args.preprocess,
        resident=args.resident,
    )


def main() -> int:
    args = parser().parse_args()
    try:
        if args.command == "doctor":
            return doctor(args.json)
        if args.command == "formats":
            return show_formats(args.json)
        if args.command == "repair-runtime":
            return repair_runtime_cli(
                requested_runtime=args.runtime,
                dry_run=args.dry_run,
                assume_yes=args.yes,
                as_json=args.json,
            )

        mod = _new_moderator(args)
        try:
            if args.command == "scan":
                result = mod.scan(
                    args.image,
                    animation_sampling=args.animation_sampling,
                    animation_max_samples=args.animation_max_samples,
                    animation_batch_size=args.animation_batch_size,
                )
                if args.json:
                    print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
                elif isinstance(result, AnimationModerationResult):
                    _print_animation(result)
                else:
                    _print_static(result)
                return 0

            if args.command == "scan-animation":
                result = mod.scan_animation(
                    args.animation,
                    sampling=args.sampling,
                    max_samples=args.max_samples,
                    batch_size=args.batch_size,
                    max_source_frames=args.max_source_frames,
                    max_duration_ms=args.max_duration_ms,
                )
                if args.json:
                    print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
                else:
                    _print_animation(result)
                return 0

            if args.command == "scan-folder":
                result = mod.scan_folder(
                    args.folder,
                    recursive=args.recursive,
                    batch_size=args.batch_size,
                    animation_sampling=args.animation_sampling,
                    animation_max_samples=args.animation_max_samples,
                    animation_batch_size=args.animation_batch_size,
                    probe_unknown=args.probe_unknown,
                )
                written = result.write_reports(
                    args.output,
                    formats=tuple(args.report_formats),
                )
                if args.json:
                    print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
                else:
                    s = result.summary
                    print("Xyran folder scan complete")
                    print(f"root       {result.root}")
                    print(f"discovered {s.discovered}")
                    print(f"scanned    {s.scanned}")
                    print(f"ALLOW      {s.allow}")
                    print(f"REVIEW     {s.review}")
                    print(f"BLOCK      {s.block}")
                    print(f"errors     {s.errors}")
                    print(f"elapsed_ms {s.elapsed_ms:.3f}")
                    for fmt, path in written.items():
                        print(f"report     {fmt.upper():<4} {Path(path).resolve()}")
                return 0 if result.summary.errors == 0 else 2
        finally:
            mod.close()

        raise RuntimeError(f"Unknown command: {args.command}")
    except (XyranError, RuntimeError, ValueError, OSError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
