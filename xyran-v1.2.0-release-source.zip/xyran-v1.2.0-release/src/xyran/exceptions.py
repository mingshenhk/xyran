class XyranError(Exception):
    """Base Xyran exception."""


class RuntimeNotInstalledError(XyranError):
    """No usable ONNX Runtime installation is available."""


class RuntimeConflictError(XyranError):
    """Multiple conflicting ONNX Runtime distributions are installed."""


class RuntimeProviderError(XyranError):
    """A requested ONNX execution provider is unavailable or unusable."""


class ModelNotFoundError(XyranError):
    """The bundled or explicitly requested ONNX model cannot be found."""


class ModelIntegrityError(XyranError):
    """The bundled model does not match the V1 release pin."""


class InvalidImageError(XyranError):
    """The image cannot be decoded or is rejected by safety limits."""


class ImageBackendError(XyranError):
    """The required local image backend is unavailable."""


class UnsupportedImageFormatError(InvalidImageError):
    """The input is a decodable file type outside Xyran's raster contract."""


class MultiFrameImageError(InvalidImageError):
    """A multi-frame or multi-page raster was supplied to the static-image API."""
