from __future__ import annotations

from dataclasses import dataclass
from importlib import import_module
from io import BytesIO
from pathlib import Path
from typing import Iterable

from PIL import Image


@dataclass(frozen=True)
class FormatSpec:
    name: str
    extensions: tuple[str, ...]
    tier: str
    multiframe_capable: bool = False


# Formats Xyran deliberately treats as raster-image inputs.
# "core" = intended for ordinary user uploads.
# "extended" = supported when the local decoder exposes the codec.
FORMAT_SPECS: tuple[FormatSpec, ...] = (
    FormatSpec("JPEG", (".jpg", ".jpeg", ".jpe"), "core"),
    FormatSpec("PNG", (".png",), "core"),
    FormatSpec("WEBP", (".webp",), "core", True),
    FormatSpec("BMP", (".bmp", ".dib"), "core"),
    FormatSpec("TIFF", (".tif", ".tiff"), "core", True),
    FormatSpec("GIF", (".gif",), "core", True),
    FormatSpec("HEIC", (".heic", ".heics"), "extended", True),
    FormatSpec("HEIF", (".heif", ".heifs", ".hif"), "extended", True),
    FormatSpec("AVIF", (".avif", ".avifs"), "extended", True),
    FormatSpec("JPEG2000", (".jp2", ".j2k", ".j2c", ".jpc", ".jpf", ".jpx"), "extended"),
    FormatSpec("ICO", (".ico",), "extended"),
)

SUPPORTED_FORMATS = frozenset(spec.name for spec in FORMAT_SPECS)
MULTIFRAME_CAPABLE = frozenset(
    spec.name for spec in FORMAT_SPECS if spec.multiframe_capable
)

# Vector/document/container formats are intentionally outside the image
# moderation contract even if a system libvips installation happens to decode them.
HARD_REJECTED_FORMATS = frozenset({"PDF", "SVG", "PSD"})

EXTENSION_TO_FORMAT = {
    ext: spec.name
    for spec in FORMAT_SPECS
    for ext in spec.extensions
}
EXTENSION_TO_FORMAT.update({
    ".pdf": "PDF",
    ".svg": "SVG",
    ".svgz": "SVG",
    ".psd": "PSD",
})


def normalize_format_name(value: str | None) -> str | None:
    if not value:
        return None
    value = str(value).strip().upper().replace(" ", "")
    aliases = {
        "JPG": "JPEG",
        "JPE": "JPEG",
        "TIF": "TIFF",
        "JP2": "JPEG2000",
        "J2K": "JPEG2000",
        "JPEG2K": "JPEG2000",
        "JPEG2000": "JPEG2000",
        "HEIF": "HEIF",
        "HEIC": "HEIC",
        "AVIF": "AVIF",
    }
    return aliases.get(value, value)


def _read_header(source, limit: int = 4096) -> bytes:
    if isinstance(source, (bytes, bytearray)):
        return bytes(source[:limit])

    if isinstance(source, Image.Image):
        return b""

    try:
        path = Path(source)
        with path.open("rb") as f:
            return f.read(limit)
    except Exception:
        return b""


def sniff_format_from_bytes(data: bytes) -> str | None:
    if not data:
        return None

    # JPEG
    if data.startswith(b"\xff\xd8\xff"):
        return "JPEG"

    # PNG
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "PNG"

    # GIF
    if data.startswith((b"GIF87a", b"GIF89a")):
        return "GIF"

    # WebP
    if len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "WEBP"

    # BMP
    if data.startswith(b"BM"):
        return "BMP"

    # TIFF
    if data.startswith((b"II*\x00", b"MM\x00*")):
        return "TIFF"

    # JPEG 2000 JP2 container or raw codestream
    if data.startswith(b"\x00\x00\x00\x0cjP  \r\n\x87\n"):
        return "JPEG2000"
    if data.startswith(b"\xffO\xffQ"):
        return "JPEG2000"

    # ICO
    if data.startswith(b"\x00\x00\x01\x00"):
        return "ICO"

    # PDF
    if data.startswith(b"%PDF-"):
        return "PDF"

    # Photoshop PSD
    if data.startswith(b"8BPS"):
        return "PSD"

    # ISO-BMFF family: HEIC / HEIF / AVIF.
    if len(data) >= 16 and data[4:8] == b"ftyp":
        brands = []
        brands.append(data[8:12])
        # Compatible brands follow the minor version field.
        for i in range(16, min(len(data), 96), 4):
            if i + 4 <= len(data):
                brands.append(data[i:i+4])

        if any(b in {b"avif", b"avis"} for b in brands):
            return "AVIF"
        if any(b in {b"heic", b"heix", b"hevc", b"hevx"} for b in brands):
            return "HEIC"
        if any(b in {b"mif1", b"msf1"} for b in brands):
            return "HEIF"

    # SVG is text/XML, so inspect a small normalized prefix.
    prefix = data[:2048].lstrip(b"\xef\xbb\xbf\x00\t\r\n ")
    lower = prefix.lower()
    if lower.startswith(b"<svg") or (
        lower.startswith(b"<?xml") and b"<svg" in lower
    ):
        return "SVG"

    return None


def identify_source_format(source) -> str | None:
    if isinstance(source, Image.Image):
        return normalize_format_name(getattr(source, "format", None))

    by_magic = sniff_format_from_bytes(_read_header(source))
    if by_magic:
        return by_magic

    if not isinstance(source, (bytes, bytearray)):
        try:
            ext = Path(source).suffix.lower()
            if ext in EXTENSION_TO_FORMAT:
                return EXTENSION_TO_FORMAT[ext]
        except Exception:
            pass

    return None


def format_from_vips_loader(image) -> str | None:
    """Best-effort mapping from libvips loader metadata to Xyran names."""
    try:
        if image.get_typeof("vips-loader") == 0:
            return None
        loader = str(image.get("vips-loader")).lower()
    except Exception:
        return None

    mapping = (
        ("jpegload", "JPEG"),
        ("pngload", "PNG"),
        ("webpload", "WEBP"),
        ("gifload", "GIF"),
        ("tiffload", "TIFF"),
        ("heifload", "HEIF"),
        ("jp2kload", "JPEG2000"),
        ("magickload", None),
    )
    for needle, name in mapping:
        if needle in loader:
            return name
    return None


def _suffixes_from_pyvips() -> set[str]:
    try:
        vips = import_module("pyvips")
        fn = getattr(vips, "get_suffixes", None)
        if fn is None:
            base = import_module("pyvips.base")
            fn = getattr(base, "get_suffixes")
        return {str(x).lower() for x in fn()}
    except Exception:
        return set()


def _suffixes_from_pillow() -> set[str]:
    try:
        Image.init()
        return {str(x).lower() for x in Image.registered_extensions().keys()}
    except Exception:
        return set()


def format_diagnostics() -> dict:
    vips_suffixes = _suffixes_from_pyvips()
    pillow_suffixes = _suffixes_from_pillow()

    rows = []
    for spec in FORMAT_SPECS:
        vips_ok = any(ext in vips_suffixes for ext in spec.extensions)
        pillow_ok = any(ext in pillow_suffixes for ext in spec.extensions)
        backends = []
        if vips_ok:
            backends.append("libvips")
        if pillow_ok:
            backends.append("Pillow")
        if spec.name in {"GIF", "WEBP"}:
            multiframe_policy = "SMART_OR_ALL"
        elif spec.multiframe_capable:
            multiframe_policy = "REJECT"
        else:
            multiframe_policy = "N/A"
        rows.append({
            "name": spec.name,
            "extensions": list(spec.extensions),
            "tier": spec.tier,
            "available": bool(backends),
            "backends": backends,
            "multiframe_capable": spec.multiframe_capable,
            "multiframe_policy": multiframe_policy,
        })

    return {
        "formats": rows,
        "multiframe_policy": "GIF/WEBP=SMART_OR_ALL; OTHER_MULTIFRAME=REJECT",
        "animated_gif": "SUPPORTED" if ".gif" in pillow_suffixes else "UNAVAILABLE",
        "animated_webp": "SUPPORTED" if ".webp" in pillow_suffixes else "UNAVAILABLE",
        "animation_backend": "Pillow sequence decoder -> pyvips preprocessing -> ONNX batch",
        "animation_default_sampling": "smart",
        "animation_default_max_samples": 32,
        "animation_default_batch_size": 16,
        "vector_svg": "NOT_SUPPORTED",
        "pdf": "NOT_SUPPORTED",
    }


def supported_extension_text(tier: str | None = None) -> str:
    specs: Iterable[FormatSpec] = FORMAT_SPECS
    if tier is not None:
        specs = (x for x in specs if x.tier == tier)
    return ", ".join(
        f"{spec.name} ({'/'.join(spec.extensions)})"
        for spec in specs
    )
