from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
from threading import RLock
from time import perf_counter
from typing import Iterable
import gc

import numpy as np

from .animation import (
    DEFAULT_ANIMATION_BATCH_SIZE,
    DEFAULT_ANIMATION_SAMPLES,
    DEFAULT_MAX_DURATION_MS,
    DEFAULT_MAX_SOURCE_FRAMES,
    SUPPORTED_ANIMATION_FORMATS,
    AnimationSampling,
    analyze_animation,
    extract_selected_frames,
    probe_media,
)
from .exceptions import InvalidImageError, MultiFrameImageError
from .formats import EXTENSION_TO_FORMAT, SUPPORTED_FORMATS, identify_source_format
from .model_info import resolve_model_path, verify_bundled_model
from .policy import ModerationPolicy
from .preprocess import DEFAULT_MAX_PIXELS, ImageInput, PreparedImage, preprocess_image
from .result import (
    AnimationFrameResult,
    AnimationModerationResult,
    AnimationProcessingInfo,
    FolderItemResult,
    FolderScanResult,
    FolderScanSummary,
    ModerationResult,
    ModerationScores,
    ProcessingInfo,
)
from .runtime import create_cpu_session, create_session


class Moderator:
    """Xyran local image and animation moderation API."""

    def __init__(
        self,
        *,
        model_path: str | Path | None = None,
        device: str = "auto",
        policy: ModerationPolicy | None = None,
        preprocess: str = "blurpad",
        resident: bool = True,
        max_pixels: int = DEFAULT_MAX_PIXELS,
        verify_model: bool = True,
    ) -> None:
        self.model_path, self._bundled_model = resolve_model_path(model_path)
        if self._bundled_model and verify_model:
            verify_bundled_model(str(self.model_path))

        self.requested_device = device.lower()
        self.policy = policy or ModerationPolicy()
        self.preprocess = preprocess.lower()
        if self.preprocess not in {"blurpad", "warp"}:
            raise ValueError("preprocess must be one of: blurpad, warp")
        self.resident = bool(resident)
        self.max_pixels = max_pixels

        self._session = None
        self._input_name = None
        self._provider = None
        self._runtime_fallback = False
        self._warnings: list[str] = []
        self._lock = RLock()

        if self.resident:
            self.load()

    @property
    def is_loaded(self) -> bool:
        return self._session is not None

    @property
    def provider(self) -> str | None:
        return self._provider

    def _refresh_metadata(self) -> None:
        inputs = self._session.get_inputs()
        if len(inputs) != 1:
            raise RuntimeError(f"Expected one ONNX input, found {len(inputs)}")
        shape = inputs[0].shape
        if len(shape) != 4 or shape[2] != 224 or shape[3] != 224:
            raise RuntimeError(
                f"Expected an Owen-S-compatible [batch,3,224,224] input, got {shape}"
            )
        # Batch dimension must be dynamic for real frame/image batching.
        if isinstance(shape[0], int) and shape[0] == 1:
            raise RuntimeError(
                "Bundled model unexpectedly has a fixed batch dimension of 1; "
                "Xyran 1.1 requires dynamic batch support."
            )
        self._input_name = inputs[0].name
        providers = self._session.get_providers()
        self._provider = providers[0] if providers else "unknown"

    def load(self) -> "Moderator":
        with self._lock:
            if self._session is not None:
                return self
            self._runtime_fallback = False
            self._warnings = []
            session, fallback, warnings = create_session(
                self.model_path, self.requested_device
            )
            self._session = session
            self._runtime_fallback = self._runtime_fallback or fallback
            for warning in warnings:
                if warning not in self._warnings:
                    self._warnings.append(warning)
            self._refresh_metadata()
            return self

    def unload(self) -> None:
        with self._lock:
            self._session = None
            self._input_name = None
            self._provider = None
            gc.collect()

    close = unload

    def __enter__(self) -> "Moderator":
        self.load()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    @contextmanager
    def _operation_session(self):
        self.load()
        try:
            yield
        finally:
            if not self.resident:
                self.unload()

    def _fallback_to_cpu(self, reason: Exception) -> None:
        if self.requested_device != "auto" or self._provider != "CUDAExecutionProvider":
            raise reason
        warning = (
            "CUDA inference failed; CPU fallback was used. "
            f"{type(reason).__name__}: {reason}"
        )
        if warning not in self._warnings:
            self._warnings.append(warning)
        self._session = create_cpu_session(self.model_path)
        self._runtime_fallback = True
        self._refresh_metadata()

    def _infer_batch(self, tensor: np.ndarray) -> np.ndarray:
        if tensor.ndim != 4 or tensor.shape[1:] != (3, 224, 224):
            raise ValueError(f"Expected [batch,3,224,224], got {tensor.shape}")
        try:
            raw = self._session.run(None, {self._input_name: tensor})[0]
        except Exception as exc:
            self._fallback_to_cpu(exc)
            raw = self._session.run(None, {self._input_name: tensor})[0]

        probs = np.asarray(raw, dtype=np.float32)
        expected = int(tensor.shape[0]) * 3
        if probs.size != expected:
            raise RuntimeError(
                f"Expected {tensor.shape[0]}x3 probabilities [NSFL,NSFW,SFW], "
                f"got {probs.shape}"
            )
        return probs.reshape(int(tensor.shape[0]), 3)

    def _infer(self, tensor: np.ndarray) -> np.ndarray:
        return self._infer_batch(tensor)[0]

    def _scores_and_decision(self, probs: np.ndarray):
        scores = ModerationScores(
            graphic=float(probs[0]),
            sexual=float(probs[1]),
            safe=float(probs[2]),
        )
        decision, category, score, threshold = self.policy.decide(scores)
        return scores, decision, category, score, threshold

    def _build_static_result(
        self,
        prepared: PreparedImage,
        probs: np.ndarray,
        *,
        preprocess_ms: float,
        inference_ms: float,
        total_ms: float,
        batch_size: int = 1,
    ) -> ModerationResult:
        scores, decision, category, score, threshold = self._scores_and_decision(probs)
        return ModerationResult(
            schema_version="1.1",
            scores=scores,
            decision=decision,
            trigger_category=category,
            trigger_score=score,
            threshold=threshold,
            provider=self._provider or "unknown",
            runtime_fallback=self._runtime_fallback,
            warnings=tuple([*prepared.warnings, *self._warnings]),
            processing=ProcessingInfo(
                original_width=prepared.width,
                original_height=prepared.height,
                preprocess=prepared.preprocess,
                image_backend=prepared.backend,
                model_resident=self.resident,
                preprocess_ms=round(preprocess_ms, 4),
                inference_ms=round(inference_ms, 4),
                total_ms=round(total_ms, 4),
                source_format=prepared.source_format,
                batch_size=batch_size,
            ),
        )

    def _scan_static_loaded(self, image: ImageInput) -> ModerationResult:
        total_start = perf_counter()
        prep_start = perf_counter()
        prepared = preprocess_image(
            image,
            preprocess=self.preprocess,
            max_pixels=self.max_pixels,
        )
        preprocess_ms = (perf_counter() - prep_start) * 1000.0

        infer_start = perf_counter()
        probs = self._infer(prepared.tensor)
        inference_ms = (perf_counter() - infer_start) * 1000.0
        total_ms = (perf_counter() - total_start) * 1000.0
        return self._build_static_result(
            prepared,
            probs,
            preprocess_ms=preprocess_ms,
            inference_ms=inference_ms,
            total_ms=total_ms,
            batch_size=1,
        )

    def _scan_static_batch_loaded(
        self,
        images: list[ImageInput],
        *,
        batch_size: int,
    ) -> list[ModerationResult]:
        if batch_size <= 0:
            raise ValueError("batch_size must be > 0")
        results: list[ModerationResult] = []

        for offset in range(0, len(images), batch_size):
            chunk = images[offset : offset + batch_size]
            chunk_start = perf_counter()
            prepared_records: list[tuple[PreparedImage, float]] = []
            for image in chunk:
                prep_start = perf_counter()
                prepared = preprocess_image(
                    image,
                    preprocess=self.preprocess,
                    max_pixels=self.max_pixels,
                )
                prepared_records.append(
                    (prepared, (perf_counter() - prep_start) * 1000.0)
                )

            tensor = np.concatenate(
                [prepared.tensor for prepared, _ in prepared_records], axis=0
            )
            infer_start = perf_counter()
            probs_batch = self._infer_batch(tensor)
            batch_inference_ms = (perf_counter() - infer_start) * 1000.0
            per_item_inference_ms = batch_inference_ms / len(chunk)
            shared_total_ms = (perf_counter() - chunk_start) * 1000.0 / len(chunk)

            for (prepared, preprocess_ms), probs in zip(prepared_records, probs_batch):
                results.append(
                    self._build_static_result(
                        prepared,
                        probs,
                        preprocess_ms=preprocess_ms,
                        inference_ms=per_item_inference_ms,
                        total_ms=preprocess_ms + per_item_inference_ms,
                        batch_size=len(chunk),
                    )
                )
        return results

    def _scan_animation_loaded(
        self,
        source: ImageInput,
        *,
        sampling: AnimationSampling,
        max_samples: int,
        batch_size: int,
        max_source_frames: int,
        max_duration_ms: int,
    ) -> AnimationModerationResult:
        total_start = perf_counter()
        analysis = analyze_animation(
            source,
            sampling=sampling,
            max_samples=max_samples,
            max_source_frames=max_source_frames,
            max_duration_ms=max_duration_ms,
            max_pixels=self.max_pixels,
        )

        selected = extract_selected_frames(source, analysis)
        prepared_records: list[tuple[object, PreparedImage, float]] = []
        prep_total = 0.0
        try:
            for meta, frame in selected:
                prep_start = perf_counter()
                prepared = preprocess_image(
                    frame,
                    preprocess=self.preprocess,
                    max_pixels=self.max_pixels,
                )
                prep_ms = (perf_counter() - prep_start) * 1000.0
                prep_total += prep_ms
                prepared_records.append((meta, prepared, prep_ms))
        finally:
            for _, frame in selected:
                try:
                    frame.close()
                except Exception:
                    pass

        frame_results: list[AnimationFrameResult] = []
        inference_total = 0.0
        for offset in range(0, len(prepared_records), batch_size):
            chunk = prepared_records[offset : offset + batch_size]
            tensor = np.concatenate([prepared.tensor for _, prepared, _ in chunk], axis=0)
            infer_start = perf_counter()
            probs_batch = self._infer_batch(tensor)
            chunk_inference_ms = (perf_counter() - infer_start) * 1000.0
            inference_total += chunk_inference_ms
            per_frame_inference_ms = chunk_inference_ms / len(chunk)

            for (meta, _prepared, prep_ms), probs in zip(chunk, probs_batch):
                scores, decision, category, score, threshold = self._scores_and_decision(probs)
                frame_results.append(
                    AnimationFrameResult(
                        frame_index=meta.index,
                        timestamp_ms=meta.timestamp_ms,
                        duration_ms=meta.duration_ms,
                        change_score=meta.change_score,
                        selection_reasons=analysis.selection_reasons[meta.index],
                        scores=scores,
                        decision=decision,
                        trigger_category=category,
                        trigger_score=score,
                        threshold=threshold,
                        preprocess_ms=round(prep_ms, 4),
                        inference_ms=round(per_frame_inference_ms, 4),
                    )
                )

        severity = {"ALLOW": 0, "REVIEW": 1, "BLOCK": 2}
        worst = max(
            frame_results,
            key=lambda frame: (
                severity[frame.decision],
                max(frame.scores.sexual, frame.scores.graphic),
                frame.scores.confidence,
                -frame.frame_index,
            ),
        )

        peak_scores = ModerationScores(
            sexual=max(frame.scores.sexual for frame in frame_results),
            graphic=max(frame.scores.graphic for frame in frame_results),
            safe=min(frame.scores.safe for frame in frame_results),
        )

        warnings = list(self._warnings)
        if not analysis.exhaustive:
            warnings.append(
                f"Animation sampling inspected {len(frame_results)} of "
                f"{analysis.probe.frame_count} frames. Use sampling='all' for "
                "exhaustive frame moderation."
            )

        total_ms = (perf_counter() - total_start) * 1000.0
        return AnimationModerationResult(
            schema_version="1.1",
            decision=worst.decision,
            peak_scores=peak_scores,
            worst_frame=worst,
            frames=tuple(frame_results),
            provider=self._provider or "unknown",
            runtime_fallback=self._runtime_fallback,
            warnings=tuple(dict.fromkeys(warnings)),
            processing=AnimationProcessingInfo(
                original_width=analysis.probe.width,
                original_height=analysis.probe.height,
                source_format=analysis.probe.source_format,
                total_frames=analysis.probe.frame_count,
                sampled_frames=len(frame_results),
                total_duration_ms=analysis.probe.duration_ms,
                sampling=sampling,
                exhaustive=analysis.exhaustive,
                batch_size=batch_size,
                analysis_ms=analysis.analysis_ms,
                preprocess_ms=round(prep_total, 4),
                inference_ms=round(inference_total, 4),
                total_ms=round(total_ms, 4),
                model_resident=self.resident,
            ),
        )

    def scan(
        self,
        image: ImageInput,
        *,
        animation_sampling: AnimationSampling = "smart",
        animation_max_samples: int = DEFAULT_ANIMATION_SAMPLES,
        animation_batch_size: int = DEFAULT_ANIMATION_BATCH_SIZE,
        animation_max_source_frames: int = DEFAULT_MAX_SOURCE_FRAMES,
        animation_max_duration_ms: int = DEFAULT_MAX_DURATION_MS,
    ) -> ModerationResult | AnimationModerationResult:
        """Scan one image; animated GIF/WebP are auto-dispatched frame-aware."""
        with self._operation_session():
            fmt = identify_source_format(image)
            if fmt in SUPPORTED_ANIMATION_FORMATS:
                probe = probe_media(image, max_pixels=self.max_pixels)
                if probe.frame_count > 1:
                    return self._scan_animation_loaded(
                        image,
                        sampling=animation_sampling,
                        max_samples=animation_max_samples,
                        batch_size=animation_batch_size,
                        max_source_frames=animation_max_source_frames,
                        max_duration_ms=animation_max_duration_ms,
                    )
            return self._scan_static_loaded(image)

    def scan_animation(
        self,
        animation: ImageInput,
        *,
        sampling: AnimationSampling = "smart",
        max_samples: int = DEFAULT_ANIMATION_SAMPLES,
        batch_size: int = DEFAULT_ANIMATION_BATCH_SIZE,
        max_source_frames: int = DEFAULT_MAX_SOURCE_FRAMES,
        max_duration_ms: int = DEFAULT_MAX_DURATION_MS,
    ) -> AnimationModerationResult:
        if batch_size <= 0:
            raise ValueError("batch_size must be > 0")
        with self._operation_session():
            return self._scan_animation_loaded(
                animation,
                sampling=sampling,
                max_samples=max_samples,
                batch_size=batch_size,
                max_source_frames=max_source_frames,
                max_duration_ms=max_duration_ms,
            )

    def scan_batch(
        self,
        images: Iterable[ImageInput],
        *,
        batch_size: int = DEFAULT_ANIMATION_BATCH_SIZE,
    ) -> list[ModerationResult]:
        """True ONNX batching for static images. Animated inputs use scan_animation()."""
        items = list(images)
        if not items:
            return []
        with self._operation_session():
            return self._scan_static_batch_loaded(items, batch_size=batch_size)

    def scan_folder(
        self,
        folder: str | Path,
        *,
        recursive: bool = True,
        batch_size: int = DEFAULT_ANIMATION_BATCH_SIZE,
        animation_sampling: AnimationSampling = "smart",
        animation_max_samples: int = DEFAULT_ANIMATION_SAMPLES,
        animation_batch_size: int = DEFAULT_ANIMATION_BATCH_SIZE,
        animation_max_source_frames: int = DEFAULT_MAX_SOURCE_FRAMES,
        animation_max_duration_ms: int = DEFAULT_MAX_DURATION_MS,
        probe_unknown: bool = False,
    ) -> FolderScanResult:
        """Scan a directory once and return structured per-file results.

        Known raster extensions are discovered by default. Set probe_unknown=True
        to attempt Pillow probing for every regular file (useful when extensions
        are untrusted, but slower on mixed-content directories).
        """
        root = Path(folder).expanduser().resolve()
        if not root.is_dir():
            raise ValueError(f"Not a directory: {root}")
        if batch_size <= 0 or animation_batch_size <= 0:
            raise ValueError("batch sizes must be > 0")

        scan_start = perf_counter()
        candidate_extensions = {
            ext for ext, fmt in EXTENSION_TO_FORMAT.items() if fmt in SUPPORTED_FORMATS
        }
        iterator = root.rglob("*") if recursive else root.glob("*")
        paths = sorted(
            (
                path for path in iterator
                if path.is_file() and (probe_unknown or path.suffix.lower() in candidate_extensions)
            ),
            key=lambda p: p.relative_to(root).as_posix().lower(),
        )

        items_by_path: dict[Path, FolderItemResult] = {}
        static_paths: list[tuple[Path, str]] = []
        animation_paths: list[tuple[Path, str]] = []

        # Probe only formats that need animation dispatch. Other supported
        # families stay on the libvips-first static path, preserving HEIC/HEIF
        # support even on systems where Pillow lacks that optional codec.
        for path in paths:
            rel = path.relative_to(root).as_posix()
            try:
                fmt = identify_source_format(path)
                if fmt is None and probe_unknown:
                    fmt = probe_media(path, max_pixels=self.max_pixels).source_format
                if fmt not in SUPPORTED_FORMATS:
                    raise InvalidImageError(f"Unsupported image format: {fmt or 'UNKNOWN'}")

                if fmt in SUPPORTED_ANIMATION_FORMATS:
                    probe = probe_media(path, max_pixels=self.max_pixels)
                    if probe.frame_count > 1:
                        animation_paths.append((path, fmt))
                    else:
                        static_paths.append((path, fmt))
                else:
                    # Multi-page TIFF/HEIF/APNG remain fail-closed in the static
                    # preprocessor. If a grouped batch hits one, the fallback
                    # below isolates it and records a per-file error.
                    static_paths.append((path, fmt))
            except Exception as exc:
                items_by_path[path] = FolderItemResult(
                    relative_path=rel,
                    absolute_path=str(path),
                    status="ERROR",
                    media_type=None,
                    source_format=identify_source_format(path),
                    decision=None,
                    result=None,
                    error_type=type(exc).__name__,
                    error=str(exc),
                )

        with self._operation_session():
            # Static files: process in real ONNX batches. If one chunk fails,
            # isolate the problematic file by falling back to per-file scans.
            for offset in range(0, len(static_paths), batch_size):
                chunk = static_paths[offset : offset + batch_size]
                chunk_paths = [path for path, _ in chunk]
                try:
                    results = self._scan_static_batch_loaded(chunk_paths, batch_size=batch_size)
                    pairs = zip(chunk, results)
                    for (path, fmt), result in pairs:
                        items_by_path[path] = FolderItemResult(
                            relative_path=path.relative_to(root).as_posix(),
                            absolute_path=str(path),
                            status="OK",
                            media_type="image",
                            source_format=result.processing.source_format or fmt,
                            decision=result.decision,
                            result=result.to_dict(),
                        )
                except Exception:
                    for path, fmt in chunk:
                        try:
                            result = self._scan_static_loaded(path)
                            items_by_path[path] = FolderItemResult(
                                relative_path=path.relative_to(root).as_posix(),
                                absolute_path=str(path),
                                status="OK",
                                media_type="image",
                                source_format=result.processing.source_format or fmt,
                                decision=result.decision,
                                result=result.to_dict(),
                            )
                        except Exception as exc:
                            items_by_path[path] = FolderItemResult(
                                relative_path=path.relative_to(root).as_posix(),
                                absolute_path=str(path),
                                status="ERROR",
                                media_type="image",
                                source_format=fmt,
                                decision=None,
                                result=None,
                                error_type=type(exc).__name__,
                                error=str(exc),
                            )

            # Animation frames are batched inside each file. Keeping animations
            # separate preserves per-file temporal metadata and bounded memory.
            for path, fmt in animation_paths:
                try:
                    result = self._scan_animation_loaded(
                        path,
                        sampling=animation_sampling,
                        max_samples=animation_max_samples,
                        batch_size=animation_batch_size,
                        max_source_frames=animation_max_source_frames,
                        max_duration_ms=animation_max_duration_ms,
                    )
                    items_by_path[path] = FolderItemResult(
                        relative_path=path.relative_to(root).as_posix(),
                        absolute_path=str(path),
                        status="OK",
                        media_type="animation",
                        source_format=fmt,
                        decision=result.decision,
                        result=result.to_dict(),
                    )
                except Exception as exc:
                    items_by_path[path] = FolderItemResult(
                        relative_path=path.relative_to(root).as_posix(),
                        absolute_path=str(path),
                        status="ERROR",
                        media_type="animation",
                        source_format=fmt,
                        decision=None,
                        result=None,
                        error_type=type(exc).__name__,
                        error=str(exc),
                    )

        ordered_items = tuple(items_by_path[path] for path in paths if path in items_by_path)
        scanned = sum(item.status == "OK" for item in ordered_items)
        errors = sum(item.status == "ERROR" for item in ordered_items)
        skipped = sum(item.status == "SKIPPED" for item in ordered_items)
        summary = FolderScanSummary(
            discovered=len(paths),
            scanned=scanned,
            static_images=sum(item.status == "OK" and item.media_type == "image" for item in ordered_items),
            animations=sum(item.status == "OK" and item.media_type == "animation" for item in ordered_items),
            allow=sum(item.decision == "ALLOW" for item in ordered_items),
            review=sum(item.decision == "REVIEW" for item in ordered_items),
            block=sum(item.decision == "BLOCK" for item in ordered_items),
            errors=errors,
            skipped=skipped,
            elapsed_ms=round((perf_counter() - scan_start) * 1000.0, 4),
        )
        return FolderScanResult(
            schema_version="1.1",
            root=str(root),
            recursive=recursive,
            items=ordered_items,
            summary=summary,
            provider=self._provider or "unknown",
            runtime_fallback=self._runtime_fallback,
            warnings=tuple(self._warnings),
        )
