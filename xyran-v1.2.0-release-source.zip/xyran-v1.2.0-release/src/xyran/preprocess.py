from __future__ import annotations

from dataclasses import dataclass
from importlib import import_module
from io import BytesIO
from pathlib import Path
from typing import Union

import numpy as np
from PIL import Image, ImageOps, UnidentifiedImageError

from .exceptions import (
    ImageBackendError,
    InvalidImageError,
    MultiFrameImageError,
    UnsupportedImageFormatError,
)
from .formats import (
    HARD_REJECTED_FORMATS,
    SUPPORTED_FORMATS,
    format_from_vips_loader,
    identify_source_format,
    normalize_format_name,
    supported_extension_text,
)

ImageInput = Union[str, Path, bytes, bytearray, Image.Image]
TARGET = 224
DEFAULT_MAX_PIXELS = 80_000_000
Image.MAX_IMAGE_PIXELS = DEFAULT_MAX_PIXELS


@dataclass(frozen=True)
class LoadedImage:
    image: object
    source_format: str
    page_count: int


@dataclass(frozen=True)
class PreparedImage:
    tensor: np.ndarray
    width: int
    height: int
    preprocess: str
    backend: str
    source_format: str = "UNKNOWN"
    page_count: int = 1
    warnings: tuple[str, ...] = ()


def fit_dimensions(width: int, height: int, target: int = TARGET) -> tuple[int, int]:
    if width <= 0 or height <= 0:
        raise InvalidImageError("Image dimensions must be positive")
    scale = min(target / width, target / height)
    out_w = max(1, min(target, round(width * scale)))
    out_h = max(1, min(target, round(height * scale)))
    return out_w, out_h


def _pyvips():
    try:
        return import_module("pyvips")
    except Exception as exc:
        raise ImageBackendError(
            "pyvips/libvips is unavailable. Reinstall Xyran so the "
            "`pyvips[binary]` dependency is present."
        ) from exc


def pyvips_diagnostics() -> dict:
    try:
        vips = import_module("pyvips")
        return {
            "available": True,
            "version": getattr(vips, "__version__", "unknown"),
            "api_mode": getattr(vips, "API_mode", None),
            "error": None,
        }
    except Exception as exc:
        return {
            "available": False,
            "version": None,
            "api_mode": None,
            "error": f"{type(exc).__name__}: {exc}",
        }


def _pil_frame_count(image: Image.Image) -> int:
    try:
        return max(1, int(getattr(image, "n_frames", 1)))
    except Exception:
        return 1


def _pil_to_vips(image: Image.Image):
    vips = _pyvips()
    image = ImageOps.exif_transpose(image)
    # Match the libvips path: transparent pixels are flattened onto white
    # instead of silently becoming black during RGBA -> RGB conversion.
    if image.mode in {"RGBA", "LA"} or "transparency" in getattr(image, "info", {}):
        rgba = image.convert("RGBA")
        background = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
        image = Image.alpha_composite(background, rgba).convert("RGB")
    else:
        image = image.convert("RGB")
    arr = np.ascontiguousarray(np.asarray(image, dtype=np.uint8))
    return vips.Image.new_from_memory(
        arr.tobytes(), image.width, image.height, 3, "uchar"
    )


def _normalize_loaded_image(image, source_format: str, page_count: int) -> LoadedImage:
    source_format = normalize_format_name(source_format) or "UNKNOWN"

    if source_format in HARD_REJECTED_FORMATS:
        raise UnsupportedImageFormatError(
            f"{source_format} is intentionally not supported by Xyran's image API. "
            "Use a raster image such as JPEG, PNG, WebP, BMP, TIFF, GIF, HEIC/HEIF "
            "or AVIF."
        )

    if source_format not in SUPPORTED_FORMATS:
        raise UnsupportedImageFormatError(
            f"Unsupported raster format: {source_format}. "
            f"Supported families: {supported_extension_text()}."
        )

    if page_count > 1:
        raise MultiFrameImageError(
            f"{source_format} contains {page_count} frames/pages. "
            "Xyran 1.2.0 intentionally refuses multi-frame inputs instead of "
            "silently scanning only frame 0. Animated GIF/WebP must be handled "
            "through Xyran's frame-aware scan()/scan_animation() path; other "
            "multi-page image families remain fail-closed."
        )

    image = image.autorot()

    try:
        if image.hasalpha():
            image = image.flatten(background=[255, 255, 255])
    except Exception:
        pass

    try:
        image = image.colourspace("srgb")
    except Exception:
        pass

    if image.bands == 1:
        band = image.extract_band(0)
        image = band.bandjoin([band, band])
    elif image.bands == 2:
        band = image.extract_band(0)
        image = band.bandjoin([band, band])
    elif image.bands >= 3:
        image = image.extract_band(0, n=3)

    if image.format != "uchar":
        image = image.cast("uchar")

    return LoadedImage(image=image, source_format=source_format, page_count=page_count)


def _load_vips(source: ImageInput) -> LoadedImage:
    vips = _pyvips()
    hinted_format = identify_source_format(source)

    # Block known vector/document inputs before asking libvips to rasterize them.
    if hinted_format in HARD_REJECTED_FORMATS:
        raise UnsupportedImageFormatError(
            f"{hinted_format} is not supported by Xyran's raster image API."
        )

    try:
        if isinstance(source, Image.Image):
            fmt = normalize_format_name(getattr(source, "format", None)) or hinted_format
            pages = _pil_frame_count(source)
            image = _pil_to_vips(source)
            return _normalize_loaded_image(image, fmt or "UNKNOWN", pages)

        if isinstance(source, (bytes, bytearray)):
            image = vips.Image.new_from_buffer(
                bytes(source), "", access="random", fail_on="error"
            )
        else:
            image = vips.Image.new_from_file(
                str(Path(source)), access="random", fail_on="error"
            )

        try:
            pages = max(1, int(image.get_n_pages()))
        except Exception:
            pages = 1

        loader_format = format_from_vips_loader(image)
        fmt = hinted_format or loader_format

        # libvips's HEIF loader is shared by HEIC/HEIF/AVIF. If magic sniffing
        # did not identify the exact family, the generic HEIF contract is safe.
        if fmt is None and loader_format == "HEIF":
            fmt = "HEIF"

        return _normalize_loaded_image(image, fmt or "UNKNOWN", pages)

    except (UnsupportedImageFormatError, MultiFrameImageError):
        raise
    except Exception as vips_exc:
        # Compatibility fallback: decode with Pillow, then return to the same
        # libvips preprocessing pipeline.
        try:
            if isinstance(source, Image.Image):
                pil = source
            elif isinstance(source, (bytes, bytearray)):
                pil = Image.open(BytesIO(source))
            else:
                pil = Image.open(Path(source))

            fmt = normalize_format_name(getattr(pil, "format", None)) or hinted_format
            pages = _pil_frame_count(pil)

            if fmt in HARD_REJECTED_FORMATS:
                raise UnsupportedImageFormatError(
                    f"{fmt} is not supported by Xyran's raster image API."
                )
            if fmt not in SUPPORTED_FORMATS:
                raise UnsupportedImageFormatError(
                    f"Unsupported raster format: {fmt or 'UNKNOWN'}."
                )
            if pages > 1:
                raise MultiFrameImageError(
                    f"{fmt} contains {pages} frames/pages. Xyran 1.2.0 "
                    "does not silently scan only the first frame."
                )

            pil.load()
            image = _pil_to_vips(pil)
            return _normalize_loaded_image(image, fmt, pages)

        except (UnsupportedImageFormatError, MultiFrameImageError):
            raise
        except (OSError, ValueError, UnidentifiedImageError) as pil_exc:
            raise InvalidImageError(
                f"Unable to decode image. libvips: {vips_exc}; Pillow: {pil_exc}"
            ) from pil_exc


def _validate_size(width: int, height: int, max_pixels: int) -> None:
    pixels = width * height
    if pixels > max_pixels:
        raise InvalidImageError(
            f"Image too large: {width}x{height} = {pixels:,} pixels; "
            f"limit is {max_pixels:,}."
        )


def _resize_exact(image, width: int, height: int, kernel: str):
    out = image.resize(
        width / image.width,
        vscale=height / image.height,
        kernel=kernel,
    )
    if out.width != width or out.height != height:
        out = image.thumbnail_image(
            width, height=height, size="force", no_rotate=True
        )
    return out


def _blurpad_lanczos3(image):
    width, height = int(image.width), int(image.height)

    background = _resize_exact(image, TARGET, TARGET, "lanczos3")
    background = background.gaussblur(10.0)

    fit_w, fit_h = fit_dimensions(width, height, TARGET)
    foreground = _resize_exact(image, fit_w, fit_h, "lanczos3")

    x = (TARGET - fit_w) // 2
    y = (TARGET - fit_h) // 2
    return background.insert(foreground, x, y)


def _warp_linear(image):
    return _resize_exact(image, TARGET, TARGET, "linear")


def _to_tensor(image) -> np.ndarray:
    if image.bands != 3:
        if image.bands > 3:
            image = image.extract_band(0, n=3)
        else:
            raise InvalidImageError(
                f"Expected 3 color bands after preprocessing, got {image.bands}."
            )
    if image.format != "uchar":
        image = image.cast("uchar")
    if image.width != TARGET or image.height != TARGET:
        raise RuntimeError(
            f"Internal preprocessing error: got {image.width}x{image.height}, "
            f"expected {TARGET}x{TARGET}."
        )

    memory = image.write_to_memory()
    pixels = np.frombuffer(
        memory,
        dtype=np.uint8,
        count=TARGET * TARGET * 3,
    ).reshape((TARGET, TARGET, 3))

    tensor = pixels.astype(np.float32).transpose(2, 0, 1)[None, ...]
    return np.ascontiguousarray(tensor)


def preprocess_image(
    source: ImageInput,
    *,
    preprocess: str = "blurpad",
    max_pixels: int = DEFAULT_MAX_PIXELS,
) -> PreparedImage:
    mode = preprocess.lower().strip()
    if mode not in {"blurpad", "warp"}:
        raise ValueError("preprocess must be one of: blurpad, warp")
    if max_pixels <= 0:
        raise ValueError("max_pixels must be > 0")

    loaded = _load_vips(source)
    image = loaded.image
    width, height = int(image.width), int(image.height)
    _validate_size(width, height, max_pixels)

    if mode == "blurpad":
        output = _blurpad_lanczos3(image)
        label = "blurpad_lanczos3"
    else:
        output = _warp_linear(image)
        label = "warp_linear"

    return PreparedImage(
        tensor=_to_tensor(output),
        width=width,
        height=height,
        preprocess=label,
        backend="pyvips",
        source_format=loaded.source_format,
        page_count=loaded.page_count,
    )
