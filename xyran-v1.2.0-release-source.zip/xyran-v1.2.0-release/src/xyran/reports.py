from __future__ import annotations

import csv
import json
import os
import tempfile
from pathlib import Path

from .result import FolderItemResult, FolderScanResult

REPORT_FORMATS = frozenset({"json", "md", "txt", "csv"})


def _atomic_write_text(path: Path, text: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(text)
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise
    return path


def _risk_fields(item: FolderItemResult) -> tuple[str, str, str, str]:
    if item.status != "OK" or not item.result:
        return "", "", "", ""
    if item.media_type == "animation":
        worst = item.result.get("worst_frame", {})
        scores = worst.get("scores", {})
        detail = f"worst frame {worst.get('frame_index', '?')}"
    else:
        scores = item.result.get("scores", {})
        detail = ""
    return (
        f"{float(scores.get('sexual', 0.0)):.4f}" if scores else "",
        f"{float(scores.get('graphic', 0.0)):.4f}" if scores else "",
        f"{float(scores.get('safe', 0.0)):.4f}" if scores else "",
        detail,
    )


def write_json_report(result: FolderScanResult, path: str | Path) -> Path:
    path = Path(path)
    return _atomic_write_text(
        path,
        json.dumps(result.to_dict(), ensure_ascii=False, indent=2) + "\n",
    )


def _md_escape(value: object) -> str:
    return str(value).replace("|", "\\|").replace("\n", " ").replace("\r", " ")


def write_markdown_report(result: FolderScanResult, path: str | Path) -> Path:
    s = result.summary
    lines = [
        "# Xyran Folder Moderation Report",
        "",
        f"- Root: `{_md_escape(result.root)}`",
        f"- Recursive: `{result.recursive}`",
        f"- Provider: `{_md_escape(result.provider)}`",
        f"- Model: `{_md_escape(result.model)}`",
        f"- Discovered: **{s.discovered}**",
        f"- Scanned: **{s.scanned}**",
        f"- Decisions: **{s.allow} ALLOW / {s.review} REVIEW / {s.block} BLOCK**",
        f"- Errors: **{s.errors}**",
        f"- Elapsed: **{s.elapsed_ms:.2f} ms**",
        "",
        "> Animation results may be smart-sampled. Check each animation's `processing.exhaustive` field in JSON for exhaustive coverage.",
        "",
        "| Path | Type | Format | Status | Decision | Sexual | Graphic | Safe | Detail |",
        "|---|---|---|---|---:|---:|---:|---:|---|",
    ]

    for item in result.items:
        sexual, graphic, safe, detail = _risk_fields(item)
        if item.error:
            detail = f"{item.error_type or 'Error'}: {item.error}"
        lines.append(
            "| " + " | ".join(
                _md_escape(v)
                for v in (
                    item.relative_path,
                    item.media_type or "",
                    item.source_format or "",
                    item.status,
                    item.decision or "",
                    sexual,
                    graphic,
                    safe,
                    detail,
                )
            ) + " |"
        )

    return _atomic_write_text(Path(path), "\n".join(lines) + "\n")


def write_text_report(result: FolderScanResult, path: str | Path) -> Path:
    s = result.summary
    lines = [
        "Xyran Folder Moderation Report",
        "=" * 31,
        f"Root: {result.root}",
        f"Recursive: {result.recursive}",
        f"Provider: {result.provider}",
        f"Model: {result.model}",
        f"Discovered: {s.discovered}",
        f"Scanned: {s.scanned}",
        f"ALLOW: {s.allow}",
        f"REVIEW: {s.review}",
        f"BLOCK: {s.block}",
        f"Errors: {s.errors}",
        f"Skipped: {s.skipped}",
        f"Elapsed ms: {s.elapsed_ms:.2f}",
        "",
        "Animation note: smart-sampled animations are not exhaustive unless marked exhaustive=true.",
        "",
        "Results",
        "-------",
    ]
    for item in result.items:
        sexual, graphic, safe, detail = _risk_fields(item)
        parts = [
            item.relative_path,
            f"status={item.status}",
            f"type={item.media_type or '-'}",
            f"format={item.source_format or '-'}",
            f"decision={item.decision or '-'}",
        ]
        if sexual:
            parts.extend([f"sexual={sexual}", f"graphic={graphic}", f"safe={safe}"])
        if detail:
            parts.append(detail)
        if item.error:
            parts.append(f"error={item.error_type or 'Error'}: {item.error}")
        lines.append(" | ".join(parts))
    return _atomic_write_text(Path(path), "\n".join(lines) + "\n")


def write_csv_report(result: FolderScanResult, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                "relative_path", "media_type", "source_format", "status", "decision",
                "sexual", "graphic", "safe", "detail", "error_type", "error",
            ])
            for item in result.items:
                sexual, graphic, safe, detail = _risk_fields(item)
                writer.writerow([
                    item.relative_path,
                    item.media_type or "",
                    item.source_format or "",
                    item.status,
                    item.decision or "",
                    sexual,
                    graphic,
                    safe,
                    detail,
                    item.error_type or "",
                    item.error or "",
                ])
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise
    return path


def write_reports(
    result: FolderScanResult,
    base_path: str | Path,
    *,
    formats: tuple[str, ...] = ("json", "md", "txt"),
) -> dict[str, Path]:
    base = Path(base_path)
    normalized = tuple(dict.fromkeys(str(fmt).lower().lstrip(".") for fmt in formats))
    unknown = [fmt for fmt in normalized if fmt not in REPORT_FORMATS]
    if unknown:
        raise ValueError(f"Unknown report format(s): {', '.join(unknown)}")

    # If a known suffix is supplied, treat the path as a stem so requesting
    # multiple formats does not produce report.json.md.
    if base.suffix.lower().lstrip(".") in REPORT_FORMATS:
        base = base.with_suffix("")

    writers = {
        "json": write_json_report,
        "md": write_markdown_report,
        "txt": write_text_report,
        "csv": write_csv_report,
    }
    output = {}
    for fmt in normalized:
        target = base.with_suffix("." + fmt)
        output[fmt] = writers[fmt](result, target)
    return output
