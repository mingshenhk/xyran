from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Literal

Decision = Literal["ALLOW", "REVIEW", "BLOCK"]


@dataclass(frozen=True)
class ModerationScores:
    sexual: float
    graphic: float
    safe: float

    @property
    def primary_class(self) -> str:
        values = {
            "sexual": self.sexual,
            "graphic": self.graphic,
            "safe": self.safe,
        }
        return max(values, key=values.get)

    @property
    def confidence(self) -> float:
        return max(self.sexual, self.graphic, self.safe)


@dataclass(frozen=True)
class ProcessingInfo:
    original_width: int
    original_height: int
    preprocess: str
    image_backend: str
    model_resident: bool
    preprocess_ms: float
    inference_ms: float
    total_ms: float
    source_format: str | None = None
    batch_size: int = 1


@dataclass(frozen=True)
class ModerationResult:
    schema_version: str
    scores: ModerationScores
    decision: Decision
    trigger_category: str | None
    trigger_score: float | None
    threshold: float | None
    provider: str
    runtime_fallback: bool
    warnings: tuple[str, ...]
    processing: ProcessingInfo
    model: str = "OwenElliott/image-safety-classifier-s"
    media_type: str = "image"

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class AnimationFrameResult:
    frame_index: int
    timestamp_ms: int
    duration_ms: int
    change_score: float
    selection_reasons: tuple[str, ...]
    scores: ModerationScores
    decision: Decision
    trigger_category: str | None
    trigger_score: float | None
    threshold: float | None
    preprocess_ms: float
    inference_ms: float

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class AnimationProcessingInfo:
    original_width: int
    original_height: int
    source_format: str
    total_frames: int
    sampled_frames: int
    total_duration_ms: int
    sampling: str
    exhaustive: bool
    batch_size: int
    analysis_ms: float
    preprocess_ms: float
    inference_ms: float
    total_ms: float
    image_backend: str = "pyvips"
    model_resident: bool = True


@dataclass(frozen=True)
class AnimationModerationResult:
    schema_version: str
    decision: Decision
    peak_scores: ModerationScores
    worst_frame: AnimationFrameResult
    frames: tuple[AnimationFrameResult, ...]
    provider: str
    runtime_fallback: bool
    warnings: tuple[str, ...]
    processing: AnimationProcessingInfo
    model: str = "OwenElliott/image-safety-classifier-s"
    media_type: str = "animation"

    @property
    def sampled_frame_indices(self) -> tuple[int, ...]:
        return tuple(frame.frame_index for frame in self.frames)

    def to_dict(self) -> dict:
        payload = asdict(self)
        payload["sampled_frame_indices"] = list(self.sampled_frame_indices)
        payload["peak_scores_note"] = (
            "peak_scores uses independent sexual/graphic maxima and the minimum "
            "safe score across sampled frames; it is not one probability distribution. "
            "worst_frame.scores is a real model probability vector."
        )
        return payload


@dataclass(frozen=True)
class FolderItemResult:
    relative_path: str
    absolute_path: str
    status: Literal["OK", "ERROR", "SKIPPED"]
    media_type: str | None
    source_format: str | None
    decision: Decision | None
    result: dict | None
    error_type: str | None = None
    error: str | None = None

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class FolderScanSummary:
    discovered: int
    scanned: int
    static_images: int
    animations: int
    allow: int
    review: int
    block: int
    errors: int
    skipped: int
    elapsed_ms: float


@dataclass(frozen=True)
class FolderScanResult:
    schema_version: str
    root: str
    recursive: bool
    items: tuple[FolderItemResult, ...]
    summary: FolderScanSummary
    provider: str
    runtime_fallback: bool
    warnings: tuple[str, ...]
    model: str = "OwenElliott/image-safety-classifier-s"
    media_type: str = "folder"

    def to_dict(self) -> dict:
        return asdict(self)

    def write_json(self, path: str | Path) -> Path:
        from .reports import write_json_report
        return write_json_report(self, path)

    def write_markdown(self, path: str | Path) -> Path:
        from .reports import write_markdown_report
        return write_markdown_report(self, path)

    def write_text(self, path: str | Path) -> Path:
        from .reports import write_text_report
        return write_text_report(self, path)

    def write_csv(self, path: str | Path) -> Path:
        from .reports import write_csv_report
        return write_csv_report(self, path)

    def write_reports(
        self,
        base_path: str | Path,
        formats: tuple[str, ...] = ("json", "md", "txt"),
    ) -> dict[str, Path]:
        from .reports import write_reports
        return write_reports(self, base_path, formats=formats)
