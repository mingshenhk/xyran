from __future__ import annotations

from importlib import import_module, metadata
from pathlib import Path
from typing import Any

import numpy as np

from .exceptions import (
    RuntimeConflictError,
    RuntimeNotInstalledError,
    RuntimeProviderError,
)

ORT_DISTRIBUTIONS = (
    "onnxruntime",
    "onnxruntime-gpu",
    "onnxruntime-directml",
    "onnxruntime-openvino",
)


def installed_ort_distributions() -> dict[str, str]:
    found: dict[str, str] = {}
    for name in ORT_DISTRIBUTIONS:
        try:
            found[name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            pass
    return found


def import_ort() -> Any:
    installed = installed_ort_distributions()
    if len(installed) > 1:
        readable = ", ".join(f"{k}=={v}" for k, v in installed.items())
        raise RuntimeConflictError(
            "Multiple ONNX Runtime distributions are installed: " + readable + ". "
            "They share the same Python namespace. Repair this environment by "
            "uninstalling every ONNX Runtime variant, then reinstalling the "
            "single Xyran-selected runtime. See `xyran doctor` and the README "
            "Runtime conflict repair section."
        )
    if not installed:
        raise RuntimeNotInstalledError(
            "ONNX Runtime is not installed. Run `xyran repair-runtime` or reinstall Xyran in a clean venv."
        )

    try:
        ort = import_module("onnxruntime")
    except Exception as exc:
        raise RuntimeNotInstalledError(
            "ONNX Runtime is installed but cannot be imported."
        ) from exc

    required = (
        "__version__",
        "InferenceSession",
        "SessionOptions",
        "get_available_providers",
        "GraphOptimizationLevel",
    )
    missing = [x for x in required if not hasattr(ort, x)]
    if missing:
        raise RuntimeNotInstalledError(
            "The onnxruntime namespace appears damaged; missing: " + ", ".join(missing) + ". "
            "This often happens after uninstalling one of two overlapping ORT "
            "distributions. Uninstall all ORT variants and reinstall the one "
            "selected by Xyran. Run `xyran repair-runtime`."
        )
    return ort


def preload_gpu_dlls(ort: Any) -> tuple[bool, str | None]:
    if not hasattr(ort, "preload_dlls"):
        return False, "onnxruntime.preload_dlls() unavailable"
    try:
        # directory="" prioritizes pip-installed NVIDIA runtime packages.
        try:
            ort.preload_dlls(directory="")
        except TypeError:
            ort.preload_dlls()
        return True, None
    except Exception as exc:
        return False, f"{type(exc).__name__}: {exc}"


def _session_options(ort: Any):
    options = ort.SessionOptions()
    options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
    return options


def create_cpu_session(model_path: Path):
    ort = import_ort()
    return ort.InferenceSession(
        str(model_path),
        sess_options=_session_options(ort),
        providers=["CPUExecutionProvider"],
    )


def create_session(model_path: Path, device: str):
    ort = import_ort()
    device = device.lower()
    available = list(ort.get_available_providers())
    warnings: list[str] = []
    fallback = False

    if device == "cpu":
        if "CPUExecutionProvider" not in available:
            raise RuntimeProviderError("CPUExecutionProvider is unavailable.")
        return create_cpu_session(model_path), fallback, warnings

    if device == "cuda":
        if "CUDAExecutionProvider" not in available:
            raise RuntimeProviderError(
                f"CUDAExecutionProvider is unavailable. Detected: {available}"
            )
        preload_gpu_dlls(ort)
        try:
            session = ort.InferenceSession(
                str(model_path),
                sess_options=_session_options(ort),
                providers=["CUDAExecutionProvider", "CPUExecutionProvider"],
            )
        except Exception as exc:
            raise RuntimeProviderError(
                f"CUDA session creation failed: {type(exc).__name__}: {exc}"
            ) from exc
        if not session.get_providers() or session.get_providers()[0] != "CUDAExecutionProvider":
            raise RuntimeProviderError(
                "CUDA was explicitly requested but the created session did not activate CUDA."
            )
        return session, fallback, warnings

    if device != "auto":
        raise ValueError("device must be one of: auto, cpu, cuda")

    if "CUDAExecutionProvider" in available:
        preload_gpu_dlls(ort)
        try:
            session = ort.InferenceSession(
                str(model_path),
                sess_options=_session_options(ort),
                providers=["CUDAExecutionProvider", "CPUExecutionProvider"],
            )
            if session.get_providers() and session.get_providers()[0] == "CUDAExecutionProvider":
                return session, fallback, warnings
            warnings.append(
                "CUDA provider was enumerated but not activated; CPU was selected."
            )
            fallback = True
            return create_cpu_session(model_path), fallback, warnings
        except Exception as exc:
            warnings.append(
                "CUDA session creation failed; CPU fallback was used. "
                f"{type(exc).__name__}: {exc}"
            )
            fallback = True
            return create_cpu_session(model_path), fallback, warnings

    if "CPUExecutionProvider" in available:
        return create_cpu_session(model_path), fallback, warnings

    raise RuntimeProviderError(f"No supported provider detected: {available}")


def run_zero_smoke(session) -> None:
    inputs = session.get_inputs()
    if len(inputs) != 1:
        raise RuntimeError(f"Expected one model input, found {len(inputs)}")
    sample = np.zeros((1, 3, 224, 224), dtype=np.float32)
    session.run(None, {inputs[0].name: sample})


def run_batch_smoke(session) -> None:
    inputs = session.get_inputs()
    if len(inputs) != 1:
        raise RuntimeError(f"Expected one model input, found {len(inputs)}")
    shape = inputs[0].shape
    if len(shape) != 4 or shape[2] != 224 or shape[3] != 224:
        raise RuntimeError(f"Unexpected model input shape: {shape}")
    if isinstance(shape[0], int) and shape[0] == 1:
        raise RuntimeError(f"Model batch dimension is fixed to 1: {shape}")
    sample = np.zeros((2, 3, 224, 224), dtype=np.float32)
    raw = session.run(None, {inputs[0].name: sample})[0]
    arr = np.asarray(raw)
    if arr.size != 6:
        raise RuntimeError(f"Dynamic batch smoke expected 2x3 output, got {arr.shape}")


def runtime_diagnostics(model_path: Path) -> dict:
    installed = installed_ort_distributions()
    report = {
        "installed_distributions": installed,
        "status": "UNKNOWN",
        "version": None,
        "available_providers": [],
        "active_provider": None,
        "cuda_preload": None,
        "smoke_test": "NOT_RUN",
        "batch_smoke_test": "NOT_RUN",
        "fallback": False,
        "warnings": [],
        "error": None,
    }

    try:
        ort = import_ort()
        report["version"] = ort.__version__
        report["available_providers"] = list(ort.get_available_providers())
        if "CUDAExecutionProvider" in report["available_providers"]:
            ok, err = preload_gpu_dlls(ort)
            report["cuda_preload"] = "OK" if ok else "FAILED"
            if err:
                report["cuda_preload_error"] = err

        session, fallback, warnings = create_session(model_path, "auto")
        report["active_provider"] = session.get_providers()[0]
        report["fallback"] = fallback
        report["warnings"].extend(warnings)

        try:
            run_zero_smoke(session)
            report["smoke_test"] = "PASS"
            run_batch_smoke(session)
            report["batch_smoke_test"] = "PASS"
            report["status"] = "READY"
            return report
        except Exception as cuda_exc:
            if report["active_provider"] != "CUDAExecutionProvider":
                raise

            # A provider can be enumerated and even create a session while the
            # first real CUDA kernel still fails (missing runtime/device/etc.).
            # `device=auto` is designed to remain usable in this situation.
            report["warnings"].append(
                "CUDA real-inference smoke test failed; CPU fallback was tested. "
                f"{type(cuda_exc).__name__}: {cuda_exc}"
            )
            cpu = create_cpu_session(model_path)
            run_zero_smoke(cpu)
            run_batch_smoke(cpu)
            report["active_provider"] = "CPUExecutionProvider"
            report["fallback"] = True
            report["smoke_test"] = "PASS_AFTER_CPU_FALLBACK"
            report["batch_smoke_test"] = "PASS_AFTER_CPU_FALLBACK"
            report["status"] = "READY"
            return report

    except Exception as exc:
        report["status"] = "ERROR"
        report["error"] = f"{type(exc).__name__}: {exc}"
        return report
