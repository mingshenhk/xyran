from __future__ import annotations

import json
import platform
import subprocess
import sys
from dataclasses import asdict, dataclass
from importlib import metadata
from typing import Callable, Sequence

from .runtime import ORT_DISTRIBUTIONS, installed_ort_distributions

GPU_SPEC = "onnxruntime-gpu[cuda,cudnn]>=1.29,<2"
CPU_SPEC = "onnxruntime>=1.29,<2"


@dataclass(frozen=True)
class RuntimeRepairPlan:
    python: str
    platform: str
    machine: str
    requested_runtime: str
    selected_runtime: str
    target_spec: str
    installed_before: dict[str, str]
    uninstall_command: list[str]
    install_command: list[str]


@dataclass(frozen=True)
class RuntimeRepairResult:
    status: str
    plan: RuntimeRepairPlan
    uninstall_returncode: int | None = None
    install_returncode: int | None = None
    verification_returncode: int | None = None
    verification: dict | None = None
    error: str | None = None

    def to_dict(self) -> dict:
        out = asdict(self)
        return out


def _normalized_machine() -> str:
    return platform.machine().strip().lower()


def gpu_runtime_supported_here() -> bool:
    machine = _normalized_machine()
    if sys.platform == "win32":
        return machine in {"amd64", "x86_64"}
    if sys.platform.startswith("linux"):
        return machine in {"x86_64", "amd64"}
    return False


def select_runtime(requested: str = "auto") -> tuple[str, str]:
    requested = requested.lower().strip()
    if requested not in {"auto", "cpu", "gpu"}:
        raise ValueError("runtime must be one of: auto, cpu, gpu")

    if requested == "cpu":
        return "cpu", CPU_SPEC

    if requested == "gpu":
        if not gpu_runtime_supported_here():
            raise RuntimeError(
                "The Xyran GPU runtime repair target is supported only on "
                "Windows x64 and Linux x86_64. Use --runtime cpu on this platform."
            )
        return "gpu", GPU_SPEC

    if gpu_runtime_supported_here():
        return "gpu", GPU_SPEC
    return "cpu", CPU_SPEC


def build_repair_plan(requested_runtime: str = "auto") -> RuntimeRepairPlan:
    selected, target = select_runtime(requested_runtime)
    py = sys.executable

    uninstall = [
        py, "-m", "pip", "uninstall", "-y",
        *ORT_DISTRIBUTIONS,
    ]
    install = [
        py, "-m", "pip", "install",
        "--no-cache-dir",
        "--force-reinstall",
        target,
    ]

    return RuntimeRepairPlan(
        python=py,
        platform=sys.platform,
        machine=platform.machine(),
        requested_runtime=requested_runtime,
        selected_runtime=selected,
        target_spec=target,
        installed_before=installed_ort_distributions(),
        uninstall_command=uninstall,
        install_command=install,
    )


def _verification_code() -> str:
    # Run verification in a NEW Python process. This is intentional: changing
    # overlapping ONNX Runtime distributions in the same running interpreter
    # can leave stale modules/import caches behind.
    return r"""
import json
import sys

from xyran.model_info import resolve_model_path, verify_bundled_model
from xyran.runtime import installed_ort_distributions, runtime_diagnostics

payload = {
    "installed_distributions": installed_ort_distributions(),
    "model": None,
    "runtime": None,
}
try:
    model_path, _ = resolve_model_path(None)
    payload["model"] = verify_bundled_model(str(model_path))
    payload["runtime"] = runtime_diagnostics(model_path)
    ok = payload["runtime"].get("status") == "READY"
except Exception as exc:
    payload["error"] = f"{type(exc).__name__}: {exc}"
    ok = False

print(json.dumps(payload, ensure_ascii=False))
raise SystemExit(0 if ok else 3)
""".strip()


def verification_command() -> list[str]:
    return [sys.executable, "-c", _verification_code()]


def verify_runtime_in_fresh_process(
    *,
    runner: Callable[..., subprocess.CompletedProcess] = subprocess.run,
) -> tuple[int, dict | None, str]:
    proc = runner(
        verification_command(),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    output = proc.stdout or ""

    payload = None
    # Verification prints exactly one JSON object in normal operation, but
    # tolerate unrelated Python startup messages by parsing the last JSON line.
    for line in reversed(output.splitlines()):
        line = line.strip()
        if not line.startswith("{"):
            continue
        try:
            payload = json.loads(line)
            break
        except json.JSONDecodeError:
            continue

    return proc.returncode, payload, output


def repair_runtime(
    *,
    requested_runtime: str = "auto",
    dry_run: bool = False,
    assume_yes: bool = False,
    input_fn: Callable[[str], str] = input,
    runner: Callable[..., subprocess.CompletedProcess] = subprocess.run,
) -> RuntimeRepairResult:
    plan = build_repair_plan(requested_runtime)

    if dry_run:
        return RuntimeRepairResult(status="DRY_RUN", plan=plan)

    if not assume_yes:
        answer = input_fn(
            "This will uninstall all ONNX Runtime variants from the CURRENT "
            "Python environment and reinstall one clean Xyran runtime. "
            "Continue? [y/N] "
        ).strip().lower()
        if answer not in {"y", "yes"}:
            return RuntimeRepairResult(status="CANCELLED", plan=plan)

    uninstall = runner(plan.uninstall_command)
    if uninstall.returncode != 0:
        return RuntimeRepairResult(
            status="FAILED",
            plan=plan,
            uninstall_returncode=uninstall.returncode,
            error="Failed to uninstall existing ONNX Runtime distributions.",
        )

    install = runner(plan.install_command)
    if install.returncode != 0:
        return RuntimeRepairResult(
            status="FAILED",
            plan=plan,
            uninstall_returncode=uninstall.returncode,
            install_returncode=install.returncode,
            error=(
                "Failed to install the selected ONNX Runtime. The environment "
                "may temporarily have no usable ORT runtime; rerun "
                "`xyran repair-runtime` when network/package access is available."
            ),
        )

    verify_rc, verification, verify_output = verify_runtime_in_fresh_process(
        runner=runner
    )
    if verify_rc != 0:
        error = "Fresh-process runtime verification failed."
        if verification and verification.get("runtime", {}).get("error"):
            error += " " + verification["runtime"]["error"]
        elif verify_output.strip():
            error += " " + verify_output.strip().splitlines()[-1]

        return RuntimeRepairResult(
            status="FAILED",
            plan=plan,
            uninstall_returncode=uninstall.returncode,
            install_returncode=install.returncode,
            verification_returncode=verify_rc,
            verification=verification,
            error=error,
        )

    return RuntimeRepairResult(
        status="READY",
        plan=plan,
        uninstall_returncode=uninstall.returncode,
        install_returncode=install.returncode,
        verification_returncode=verify_rc,
        verification=verification,
    )
