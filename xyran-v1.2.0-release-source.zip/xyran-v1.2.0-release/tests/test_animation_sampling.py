from pathlib import Path

from PIL import Image

from xyran.animation import (
    AnimationFrameMeta,
    analyze_animation,
    extract_selected_frames,
    select_animation_frames,
)


def test_smart_sampling_keeps_change_peak_and_endpoints():
    frames = tuple(
        AnimationFrameMeta(
            index=i,
            timestamp_ms=i * 100,
            duration_ms=100,
            change_score=0.99 if i == 37 else 0.01,
        )
        for i in range(100)
    )
    selected, reasons, exhaustive = select_animation_frames(
        frames, sampling="smart", max_samples=12
    )
    assert len(selected) == 12
    assert 0 in selected
    assert 99 in selected
    assert 37 in selected
    assert "visual_change" in reasons[37]
    assert exhaustive is False


def test_uniform_sampling_is_deterministic():
    frames = tuple(
        AnimationFrameMeta(i, i * 100, 100, 0.0)
        for i in range(50)
    )
    a = select_animation_frames(frames, sampling="uniform", max_samples=8)
    b = select_animation_frames(frames, sampling="uniform", max_samples=8)
    assert a == b
    assert len(a[0]) == 8


def test_short_animation_is_exhaustive():
    frames = tuple(AnimationFrameMeta(i, i * 50, 50, 0.1) for i in range(5))
    selected, _, exhaustive = select_animation_frames(
        frames, sampling="smart", max_samples=32
    )
    assert selected == (0, 1, 2, 3, 4)
    assert exhaustive is True


def _make_gif(path: Path):
    frames = [
        Image.new("RGB", (40, 30), (255, 0, 0)),
        Image.new("RGB", (40, 30), (0, 255, 0)),
        Image.new("RGB", (40, 30), (0, 0, 255)),
    ]
    frames[0].save(
        path,
        save_all=True,
        append_images=frames[1:],
        duration=[80, 120, 200],
        loop=0,
        format="GIF",
    )


def test_gif_analysis_and_extraction(tmp_path):
    path = tmp_path / "a.gif"
    _make_gif(path)
    analysis = analyze_animation(path, sampling="smart", max_samples=32)
    assert analysis.probe.source_format == "GIF"
    assert analysis.probe.frame_count == 3
    assert analysis.probe.duration_ms == 400
    assert analysis.exhaustive is True
    selected = extract_selected_frames(path, analysis)
    assert [meta.index for meta, _ in selected] == [0, 1, 2]
    assert all(frame.size == (40, 30) for _, frame in selected)
    for _, frame in selected:
        frame.close()


def test_webp_analysis_when_encoder_available(tmp_path):
    path = tmp_path / "a.webp"
    frames = [
        Image.new("RGB", (24, 24), (10, 20, 30)),
        Image.new("RGB", (24, 24), (220, 40, 30)),
        Image.new("RGB", (24, 24), (10, 220, 30)),
    ]
    try:
        frames[0].save(
            path,
            save_all=True,
            append_images=frames[1:],
            duration=[100, 150, 250],
            loop=0,
            format="WEBP",
        )
    except OSError:
        return
    analysis = analyze_animation(path, sampling="all")
    assert analysis.probe.source_format == "WEBP"
    assert analysis.probe.frame_count == 3
    assert analysis.probe.duration_ms == 500
    assert analysis.selected_indices == (0, 1, 2)


def test_smart_sampling_represents_long_dwell_frame():
    frames = []
    timestamp = 0
    for i in range(40):
        duration = 5000 if i == 21 else 20
        frames.append(AnimationFrameMeta(i, timestamp, duration, 0.01))
        timestamp += duration
    selected, reasons, exhaustive = select_animation_frames(
        tuple(frames), sampling="smart", max_samples=10
    )
    assert 21 in selected
    assert (
        "long_dwell" in reasons[21]
        or "time_coverage" in reasons[21]
    )
    assert exhaustive is False


def test_source_frame_limit_rejects_animation(tmp_path):
    path = tmp_path / "too_many.gif"
    frames = [Image.new("RGB", (8, 8), (i * 20, 0, 0)) for i in range(6)]
    frames[0].save(path, save_all=True, append_images=frames[1:], duration=50, loop=0)
    import pytest
    from xyran.exceptions import InvalidImageError
    with pytest.raises(InvalidImageError, match="hard limit"):
        analyze_animation(path, max_source_frames=5)


def test_change_score_is_sensitive_to_local_patch():
    import numpy as np
    from xyran.animation import _change_score
    previous = np.zeros((48, 48, 3), dtype=np.int16)
    current = previous.copy()
    current[10:16, 10:16, :] = 255
    score = _change_score(previous, current)
    # A plain global mean would be ~0.0156; local emphasis should be much higher.
    assert score > 0.10
