from xyran.cli import parser


def test_scan_animation_parser_defaults():
    args = parser().parse_args(["scan-animation", "a.gif"])
    assert args.command == "scan-animation"
    assert args.sampling == "smart"
    assert args.max_samples == 32
    assert args.batch_size == 16


def test_scan_folder_parser_reports():
    args = parser().parse_args([
        "scan-folder", "images", "--report-formats", "json", "md", "txt", "csv"
    ])
    assert args.command == "scan-folder"
    assert args.recursive is True
    assert args.report_formats == ["json", "md", "txt", "csv"]
