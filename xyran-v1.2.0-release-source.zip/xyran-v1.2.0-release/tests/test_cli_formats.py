from xyran.cli import parser


def test_formats_command_exists():
    args = parser().parse_args(["formats"])
    assert args.command == "formats"
    assert args.json is False


def test_formats_json_flag():
    args = parser().parse_args(["formats", "--json"])
    assert args.command == "formats"
    assert args.json is True
