from xyran.cli import parser


def test_repair_runtime_cli_exists():
    args = parser().parse_args(["repair-runtime", "--dry-run"])
    assert args.command == "repair-runtime"
    assert args.runtime == "auto"
    assert args.dry_run is True
    assert args.yes is False


def test_repair_runtime_force_cpu_yes_json():
    args = parser().parse_args([
        "repair-runtime",
        "--runtime", "cpu",
        "--yes",
        "--json",
    ])
    assert args.runtime == "cpu"
    assert args.yes is True
    assert args.json is True
