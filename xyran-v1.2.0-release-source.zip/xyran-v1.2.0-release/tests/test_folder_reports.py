from pathlib import Path

import numpy as np
from PIL import Image

import xyran.moderator as mm
from xyran.preprocess import PreparedImage
from xyran.result import FolderScanResult


class Input:
    name = "image"
    shape = ["batch_size", 3, 224, 224]


class FakeSession:
    def get_inputs(self):
        return [Input()]

    def get_providers(self):
        return ["CPUExecutionProvider"]

    def run(self, outputs, feed):
        n = feed["image"].shape[0]
        return [np.tile(np.array([[0.02, 0.08, 0.90]], dtype=np.float32), (n, 1))]


def fake_preprocess(image, **kwargs):
    if isinstance(image, Image.Image):
        width, height = image.size
        fmt = getattr(image, "format", None) or "GIF"
    else:
        with Image.open(image) as im:
            width, height = im.size
            fmt = im.format
    return PreparedImage(
        tensor=np.zeros((1, 3, 224, 224), dtype=np.float32),
        width=width,
        height=height,
        preprocess="blurpad_lanczos3",
        backend="pyvips",
        source_format=fmt,
        page_count=1,
    )


def test_folder_scan_static_animation_and_reports(monkeypatch, tmp_path):
    model = tmp_path / "m.onnx"
    model.write_bytes(b"x")
    monkeypatch.setattr(mm, "create_session", lambda path, device: (FakeSession(), False, []))
    monkeypatch.setattr(mm, "preprocess_image", fake_preprocess)

    media = tmp_path / "media"
    (media / "nested").mkdir(parents=True)
    Image.new("RGB", (30, 20), (1, 2, 3)).save(media / "one.png")
    gif_frames = [Image.new("RGB", (20, 20), c) for c in [(0, 0, 0), (255, 0, 0)]]
    gif_frames[0].save(
        media / "nested" / "two.gif",
        save_all=True,
        append_images=gif_frames[1:],
        duration=100,
        loop=0,
    )
    (media / "ignore.txt").write_text("not an image", encoding="utf-8")

    mod = mm.Moderator(model_path=model, resident=True, verify_model=False)
    result = mod.scan_folder(media, recursive=True, batch_size=8)
    assert isinstance(result, FolderScanResult)
    assert result.summary.discovered == 2
    assert result.summary.scanned == 2
    assert result.summary.static_images == 1
    assert result.summary.animations == 1
    assert result.summary.errors == 0

    written = result.write_reports(tmp_path / "report", formats=("json", "md", "txt", "csv"))
    assert set(written) == {"json", "md", "txt", "csv"}
    for path in written.values():
        assert path.is_file()
        assert path.stat().st_size > 0

    md = written["md"].read_text(encoding="utf-8")
    assert "one.png" in md
    assert "nested/two.gif" in md
    assert "Xyran Folder Moderation Report" in md


def test_folder_scan_isolates_corrupt_image(monkeypatch, tmp_path):
    model = tmp_path / "m2.onnx"
    model.write_bytes(b"x")
    monkeypatch.setattr(mm, "create_session", lambda path, device: (FakeSession(), False, []))

    # Use a preprocessor that fails on the corrupt path but succeeds on valid PNG.
    def selective_preprocess(image, **kwargs):
        if not isinstance(image, Image.Image) and Path(image).name == "broken.jpg":
            raise ValueError("broken fixture")
        return fake_preprocess(image, **kwargs)

    monkeypatch.setattr(mm, "preprocess_image", selective_preprocess)
    media = tmp_path / "media2"
    media.mkdir()
    Image.new("RGB", (16, 16), (1, 2, 3)).save(media / "ok.png")
    (media / "broken.jpg").write_bytes(b"not a jpeg")

    mod = mm.Moderator(model_path=model, resident=True, verify_model=False)
    result = mod.scan_folder(media, batch_size=8)
    assert result.summary.discovered == 2
    assert result.summary.scanned == 1
    assert result.summary.errors == 1
    states = {item.relative_path: item.status for item in result.items}
    assert states["ok.png"] == "OK"
    assert states["broken.jpg"] == "ERROR"
