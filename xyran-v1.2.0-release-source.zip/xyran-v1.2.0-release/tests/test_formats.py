from xyran.formats import (
    HARD_REJECTED_FORMATS,
    identify_source_format,
    sniff_format_from_bytes,
)


def test_magic_jpeg():
    assert sniff_format_from_bytes(b"\xff\xd8\xff\xe0" + b"x" * 20) == "JPEG"


def test_magic_png():
    assert sniff_format_from_bytes(b"\x89PNG\r\n\x1a\n" + b"x" * 20) == "PNG"


def test_magic_gif():
    assert sniff_format_from_bytes(b"GIF89a" + b"x" * 20) == "GIF"


def test_magic_webp():
    data = b"RIFF" + (20).to_bytes(4, "little") + b"WEBP" + b"x" * 20
    assert sniff_format_from_bytes(data) == "WEBP"


def test_magic_bmp():
    assert sniff_format_from_bytes(b"BM" + b"x" * 20) == "BMP"


def test_magic_tiff():
    assert sniff_format_from_bytes(b"II*\x00" + b"x" * 20) == "TIFF"


def test_magic_jpeg2000():
    assert sniff_format_from_bytes(b"\x00\x00\x00\x0cjP  \r\n\x87\n" + b"x" * 20) == "JPEG2000"


def test_magic_ico():
    assert sniff_format_from_bytes(b"\x00\x00\x01\x00" + b"x" * 20) == "ICO"


def test_magic_pdf_rejected_family():
    assert sniff_format_from_bytes(b"%PDF-1.7\n") == "PDF"
    assert "PDF" in HARD_REJECTED_FORMATS


def test_magic_svg_rejected_family():
    assert sniff_format_from_bytes(b'<?xml version="1.0"?><svg xmlns="http://www.w3.org/2000/svg">') == "SVG"
    assert "SVG" in HARD_REJECTED_FORMATS


def test_magic_avif():
    data = b"\x00\x00\x00\x18ftypavif\x00\x00\x00\x00avifmif1"
    assert sniff_format_from_bytes(data) == "AVIF"


def test_magic_heic():
    data = b"\x00\x00\x00\x18ftypheic\x00\x00\x00\x00heicmif1"
    assert sniff_format_from_bytes(data) == "HEIC"


def test_extension_fallback(tmp_path):
    p = tmp_path / "sample.jpeg"
    p.write_bytes(b"not-real-image")
    assert identify_source_format(p) == "JPEG"
