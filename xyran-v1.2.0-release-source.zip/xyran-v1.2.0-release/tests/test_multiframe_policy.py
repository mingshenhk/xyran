import pytest

from xyran.exceptions import MultiFrameImageError
from xyran.preprocess import _normalize_loaded_image


class FakeImage:
    def autorot(self):
        return self


def test_multiframe_is_rejected_before_pixel_processing():
    with pytest.raises(MultiFrameImageError, match="frames/pages"):
        _normalize_loaded_image(FakeImage(), "GIF", 3)
