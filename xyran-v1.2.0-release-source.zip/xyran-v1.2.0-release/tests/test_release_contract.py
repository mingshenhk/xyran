from pathlib import Path
import tomllib

ROOT = Path(__file__).resolve().parents[1]


def test_version_and_dependencies():
    data = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    project = data["project"]
    assert project["name"] == "xyran"
    assert project["version"] == "1.2.0"
    deps = "\n".join(project["dependencies"])
    assert "pyvips[binary]" in deps
    assert "onnxruntime-gpu[cuda,cudnn]" in deps
    assert "onnxruntime>=" in deps


def test_default_contract_is_blurpad_resident_no_tiling():
    source = (ROOT / "src/xyran/moderator.py").read_text(encoding="utf-8")
    assert 'preprocess: str = "blurpad"' in source
    assert 'resident: bool = True' in source
    assert "tiling" not in source.lower()


def test_model_pin_is_exact():
    source = (ROOT / "src/xyran/model_info.py").read_text(encoding="utf-8")
    assert "23_701_765" in source
    assert "fef443ed68ae25ed693b6fef9e456071" in source
    assert "eb8b0b203952b70db191e990217174af4af39767" in source


def test_v110_animation_folder_report_contract():
    moderator = (ROOT / "src/xyran/moderator.py").read_text(encoding="utf-8")
    animation = (ROOT / "src/xyran/animation.py").read_text(encoding="utf-8")
    reports = (ROOT / "src/xyran/reports.py").read_text(encoding="utf-8")
    assert "def scan_animation(" in moderator
    assert "def scan_folder(" in moderator
    assert "def _infer_batch(" in moderator
    assert 'DEFAULT_ANIMATION_SAMPLES = 32' in animation
    assert 'DEFAULT_ANIMATION_BATCH_SIZE = 16' in animation
    assert 'REPORT_FORMATS = frozenset({"json", "md", "txt", "csv"})' in reports
