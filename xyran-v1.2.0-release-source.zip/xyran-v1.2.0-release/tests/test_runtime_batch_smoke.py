import numpy as np

from xyran.runtime import run_batch_smoke


class Input:
    name = "image"
    shape = ["batch_size", 3, 224, 224]


class Session:
    def get_inputs(self):
        return [Input()]

    def run(self, outputs, feed):
        n = feed["image"].shape[0]
        return [np.zeros((n, 3), dtype=np.float32)]


def test_dynamic_batch_smoke_uses_two_items():
    run_batch_smoke(Session())
