from __future__ import annotations

import subprocess

import pytest

from xyran import runtime_repair


class DummyProc:
    def __init__(self, returncode=0, stdout=""):
        self.returncode = returncode
        self.stdout = stdout


def test_auto_runtime_selects_supported_target(monkeypatch):
    monkeypatch.setattr(runtime_repair, "gpu_runtime_supported_here", lambda: True)
    selected, spec = runtime_repair.select_runtime("auto")
    assert selected == "gpu"
    assert spec.startswith("onnxruntime-gpu[")


def test_explicit_cpu_runtime():
    selected, spec = runtime_repair.select_runtime("cpu")
    assert selected == "cpu"
    assert spec.startswith("onnxruntime>=")


def test_gpu_rejected_on_unsupported_platform(monkeypatch):
    monkeypatch.setattr(runtime_repair, "gpu_runtime_supported_here", lambda: False)
    with pytest.raises(RuntimeError, match="supported only"):
        runtime_repair.select_runtime("gpu")


def test_plan_uses_current_python_and_all_ort_variants(monkeypatch):
    monkeypatch.setattr(
        runtime_repair,
        "installed_ort_distributions",
        lambda: {"onnxruntime": "1.26.0", "onnxruntime-gpu": "1.29.0"},
    )
    monkeypatch.setattr(runtime_repair, "gpu_runtime_supported_here", lambda: True)

    plan = runtime_repair.build_repair_plan("auto")
    assert plan.uninstall_command[:4] == [
        runtime_repair.sys.executable,
        "-m",
        "pip",
        "uninstall",
    ]
    for name in runtime_repair.ORT_DISTRIBUTIONS:
        assert name in plan.uninstall_command
    assert plan.install_command[:4] == [
        runtime_repair.sys.executable,
        "-m",
        "pip",
        "install",
    ]
    assert "--force-reinstall" in plan.install_command


def test_dry_run_never_executes_runner(monkeypatch):
    monkeypatch.setattr(runtime_repair, "gpu_runtime_supported_here", lambda: True)
    called = []

    def runner(*args, **kwargs):
        called.append(args)
        raise AssertionError("runner must not be called")

    result = runtime_repair.repair_runtime(
        requested_runtime="auto",
        dry_run=True,
        assume_yes=True,
        runner=runner,
    )
    assert result.status == "DRY_RUN"
    assert called == []


def test_cancel_never_executes_runner(monkeypatch):
    monkeypatch.setattr(runtime_repair, "gpu_runtime_supported_here", lambda: True)

    def runner(*args, **kwargs):
        raise AssertionError("runner must not be called")

    result = runtime_repair.repair_runtime(
        requested_runtime="auto",
        dry_run=False,
        assume_yes=False,
        input_fn=lambda prompt: "n",
        runner=runner,
    )
    assert result.status == "CANCELLED"


def test_successful_repair_runs_uninstall_install_and_fresh_verify(monkeypatch):
    monkeypatch.setattr(runtime_repair, "gpu_runtime_supported_here", lambda: True)
    calls = []

    verify_json = (
        '{"installed_distributions":{"onnxruntime-gpu":"1.29.0"},'
        '"model":{"size_bytes":23701765},'
        '"runtime":{"status":"READY","version":"1.29.0",'
        '"available_providers":["CUDAExecutionProvider","CPUExecutionProvider"],'
        '"active_provider":"CUDAExecutionProvider","smoke_test":"PASS",'
        '"batch_smoke_test":"PASS"}}'
    )

    def runner(command, **kwargs):
        calls.append(command)
        if command[:2] == [runtime_repair.sys.executable, "-c"]:
            return DummyProc(0, verify_json + "\n")
        return DummyProc(0, "")

    result = runtime_repair.repair_runtime(
        requested_runtime="auto",
        assume_yes=True,
        runner=runner,
    )
    assert result.status == "READY"
    assert result.verification["runtime"]["status"] == "READY"
    assert len(calls) == 3


def test_install_failure_is_reported(monkeypatch):
    monkeypatch.setattr(runtime_repair, "gpu_runtime_supported_here", lambda: True)
    count = 0

    def runner(command, **kwargs):
        nonlocal count
        count += 1
        if count == 1:
            return DummyProc(0, "")
        return DummyProc(1, "network failure")

    result = runtime_repair.repair_runtime(
        requested_runtime="auto",
        assume_yes=True,
        runner=runner,
    )
    assert result.status == "FAILED"
    assert result.install_returncode == 1
    assert "temporarily have no usable ORT runtime" in result.error
