from pathlib import Path

import numpy as np
from PIL import Image

import xyran.moderator as mm
from xyran.preprocess import PreparedImage
from xyran.result import AnimationModerationResult


class Input:
    name = "image"
    shape = ["batch_size", 3, 224, 224]


class FakeSession:
    def __init__(self):
        self.batch_shapes = []

    def get_inputs(self):
        return [Input()]

    def get_providers(self):
        return ["CPUExecutionProvider"]

    def run(self, outputs, feed):
        tensor = feed["image"]
        self.batch_shapes.append(tuple(tensor.shape))
        rows = []
        for sample in tensor:
            marker = float(sample[0, 0, 0])
            sexual = min(0.95, 0.05 + 0.90 * marker)
            graphic = 0.02
            safe = max(0.03, 1.0 - sexual - graphic)
            rows.append([graphic, sexual, safe])
        return [np.asarray(rows, dtype=np.float32)]


def fake_preprocess(image, **kwargs):
    marker = 0.0
    if isinstance(image, Image.Image):
        rgb = image.convert("RGB")
        marker = rgb.getpixel((0, 0))[0] / 255.0
        width, height = rgb.size
        source_format = getattr(image, "format", None)
    else:
        width, height = 100, 100
        source_format = "JPEG"
    tensor = np.zeros((1, 3, 224, 224), dtype=np.float32)
    tensor[0, 0, 0, 0] = marker
    return PreparedImage(
        tensor=tensor,
        width=width,
        height=height,
        preprocess="blurpad_lanczos3",
        backend="pyvips",
        source_format=source_format or "GIF",
        page_count=1,
    )


def _make_mod(monkeypatch, tmp_path):
    model = tmp_path / "m.onnx"
    model.write_bytes(b"x")
    session = FakeSession()
    monkeypatch.setattr(mm, "create_session", lambda path, device: (session, False, []))
    monkeypatch.setattr(mm, "preprocess_image", fake_preprocess)
    mod = mm.Moderator(model_path=model, resident=True, verify_model=False)
    return mod, session


def test_static_scan_batch_uses_real_dynamic_batch(monkeypatch, tmp_path):
    mod, session = _make_mod(monkeypatch, tmp_path)
    results = mod.scan_batch(["a.jpg", "b.jpg", "c.jpg", "d.jpg", "e.jpg"], batch_size=4)
    assert len(results) == 5
    assert session.batch_shapes == [(4, 3, 224, 224), (1, 3, 224, 224)]
    assert results[0].processing.batch_size == 4
    assert results[-1].processing.batch_size == 1


def test_scan_auto_dispatches_animated_gif_and_batches_frames(monkeypatch, tmp_path):
    mod, session = _make_mod(monkeypatch, tmp_path)
    path = tmp_path / "risk.gif"
    frames = [
        Image.new("RGB", (32, 32), (0, 0, 0)),
        Image.new("RGB", (32, 32), (255, 0, 0)),
        Image.new("RGB", (32, 32), (0, 0, 0)),
    ]
    frames[0].save(path, save_all=True, append_images=frames[1:], duration=100, loop=0)

    result = mod.scan(path, animation_max_samples=32, animation_batch_size=16)
    assert isinstance(result, AnimationModerationResult)
    assert result.processing.exhaustive is True
    assert result.processing.sampled_frames == 3
    assert result.worst_frame.frame_index == 1
    assert result.decision == "BLOCK"
    assert session.batch_shapes[-1] == (3, 3, 224, 224)
