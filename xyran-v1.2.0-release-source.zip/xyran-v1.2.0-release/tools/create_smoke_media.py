from __future__ import annotations

from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "_xyran_smoke_media"
OUT.mkdir(exist_ok=True)
(OUT / "nested").mkdir(exist_ok=True)

Image.new("RGB", (739, 1000), (40, 80, 120)).save(OUT / "static.png")
Image.new("RGB", (640, 360), (80, 110, 140)).save(OUT / "nested" / "static.jpg")

gif_frames = [
    Image.new("RGB", (160, 120), (20, 30, 40)),
    Image.new("RGB", (160, 120), (80, 40, 20)),
    Image.new("RGB", (160, 120), (20, 80, 40)),
]
gif_frames[0].save(
    OUT / "animated.gif",
    save_all=True,
    append_images=gif_frames[1:],
    duration=[80, 120, 200],
    loop=0,
)

webp_ok = False
try:
    webp_frames = [
        Image.new("RGB", (160, 120), (10, 20, 30)),
        Image.new("RGB", (160, 120), (60, 20, 90)),
        Image.new("RGB", (160, 120), (20, 100, 30)),
    ]
    webp_frames[0].save(
        OUT / "animated.webp",
        save_all=True,
        append_images=webp_frames[1:],
        duration=[100, 150, 250],
        loop=0,
        format="WEBP",
    )
    with Image.open(OUT / "animated.webp") as im:
        webp_ok = getattr(im, "n_frames", 1) == 3
except Exception:
    (OUT / "animated.webp").unlink(missing_ok=True)

print(f"SMOKE_DIR={OUT}")
print(f"WEBP_ANIMATION={'YES' if webp_ok else 'NO'}")
